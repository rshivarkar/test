﻿using System.ServiceProcess;
using log4net.Config;
using System.Windows.Forms;
namespace RSAAlert
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        private static void Main()
        {
            XmlConfigurator.Configure();

            //ServiceBase[] ServicesToRun;
            //ServicesToRun = new ServiceBase[]
            //{
            //    new RSAAlertService()
            //};
            //ServiceBase.Run(ServicesToRun);

            Application.Run(new TestForm());
        }
    }
}