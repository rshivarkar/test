﻿window.onload = function () {
    google.charts.load('current', { 'packages': ['corechart'] });
    google.charts.load('current', { 'packages': ['annotatedtimeline'] });

    $(document).ready(function () {
        $("#serverList").change(function () {
            google.charts.setOnLoadCallback(drawAllProcessChart);
            google.charts.setOnLoadCallback(drawDISKChart);

            $("#processChartdiv").html("");
            $("#DiskChartdiv").html("");
        });

        function drawAllProcessChart() {
            server = document.getElementById("serverList").value;
            Drivename = 'CPU';

            $.ajax({
                url: 'http://localhost:8080/RSA/GetMemoryUsage?server=' + server + '&name=' + Drivename + '',
                dataType: 'json',
                beforeSend: function () {
                    $("#processChartdiv").append('<img src="Images/ajax-loading-large.gif" alt="Loading Data" style="height:100%;width:100%">');
                },
                success: function () {
                    $("#processChartdiv").html("");
                },
                complete: function (json) {
                    $("#processChartdiv").html("");
                    drawAllMemoryChartByJson(json);
                },
                error: function (err) {
                    alert('call to web API failed');
                }
            });
        }

        function drawAllMemoryChartByJson(data) {
            // <table class="tableMain" border="1" style='width: 80%; height: 340px;'></table>
            var html = '<table border="1" style="width: 90%; height: 340px;background-color:powderblue;"';
            for (var i = 0; i < data.responseJSON.length; i++) {
                var name = 'memory' + i;
                html += "<tr ><td>Process:" + data.responseJSON[i].name + "<div id=" + name + " ></div></td></tr>";
            }
            html += "</table>";
            $("#processChartdiv").append(html);

            for (var i = 0; i < data.responseJSON.length; i++) {
                var name = 'memory' + i;

                var google_chart_Data = new google.visualization.DataTable();
                google_chart_Data.addColumn('date', 'Date');
                google_chart_Data.addColumn('number', 'consumed (MB)');

                google_chart_Data.addRows(data.responseJSON[i].Memory_UsageInfo.length);
                for (var j = 0; j < data.responseJSON[i].Memory_UsageInfo.length; j++) {
                    google_chart_Data.setCell(j, 0, new Date(data.responseJSON[i].Memory_UsageInfo[j].Key));
                    google_chart_Data.setCell(j, 1, data.responseJSON[i].Memory_UsageInfo[j].Value);
                }

                var chart = new google.visualization.AnnotatedTimeLine(document.getElementById(name));
                chart.draw(google_chart_Data, { displayAnnotations: true });
            }
        }


        function drawDISKChart() {
            server = document.getElementById("serverList").value;
            Drivename = 'Disk';

            $.ajax({
                url: 'http://localhost:8080/RSA/GetMemoryUsage?server=' + server + '&name=' + Drivename + '',
                dataType: 'json',
                beforeSend: function () {
                    $("#DiskChartdiv").append('<img src="Images/ajax-loading-large.gif" alt="Loading Data" style="height:50%;width:50%">');
                },
                success: function () {
                    $("#DiskChartdiv").html("");
                },
                complete: function (json) {
                    $("#DiskChartdiv").html("");
                    drawDISKChartByJson(json);
                },
                error: function (err) {
                    alert('call to web API failed');
                }
            });
        }
        function drawDISKChartByJson(data) {
            // <table class="tableMain" border="1" style='width: 80%; height: 340px;'></table>
            var html = '<table border="1" style="width: 90%; height: 340px;"<tr>';
            for (var i = 0; i < data.responseJSON.length; i++) {
                var name = 'piechart' + i;
                html += "<td>Disk Space<div id=" + name + " ></div></td>";
            }
            html += "</tr></table>";
            $("#DiskChartdiv").append(html);

            for (var i = 0; i < data.responseJSON.length; i++) {
                var name = 'piechart' + i;
                var name = 'piechart' + i;

                var google_Chart_Data = google.visualization.arrayToDataTable([
                 ['consumed', 'Free'],
                 ['consumed', data.responseJSON[i].used],
                 ['Free', data.responseJSON[i].free]
                ]);

                var options = {
                    title: data.responseJSON[i].name,
                    height: 300,
                    width: 300
                };

                var chart = new google.visualization.PieChart(document.getElementById(name));

                chart.draw(google_Chart_Data, options);
            }
        }
    })
}