﻿using RSAAlert.Common;
using RSAAlert.XMLClasses;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace RSAAlert.AssetWise
{
    internal class Common
    {
        private static readonly string CLASSNAME = System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name + ".";

        public static void CheckSSLAndAlert(SSLConfigs objSSLConfigs)
        {
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11;
            CheckSSLAndAlertEx(objSSLConfigs);
        }

        public static void CheckSSLAndAlertEx(SSLConfigs objSSLConfigs)
        {
            StreamWriter fileLog = RSAAlert.AssetWise.Common.GetLogFileHandle("SSLAlert" + ".log");
            var watch = System.Diagnostics.Stopwatch.StartNew();

            fileLog.WriteLine("CheckSSLAndAlert started => " + DateTime.UtcNow.ToString());
            string CurrentLine = "";

            try
            {
                DataTable tblExpirary = new DataTable();
                tblExpirary.Columns.Add("Asset", typeof(String));
                tblExpirary.Columns.Add("Environment", typeof(String));
                tblExpirary.Columns.Add("URL", typeof(String));
                tblExpirary.Columns.Add("Expirary_Date", typeof(DateTime));
                tblExpirary.Columns.Add("Days_to_Expire", typeof(Int32));
                tblExpirary.Columns.Add("Exception", typeof(String));

                string strPDL = objSSLConfigs.AlertEMails;

                foreach (SSLConfig objSSLconfig in objSSLConfigs.SSLConfig)
                {
                    foreach (string strConfigURL in objSSLconfig.URLS.URL)
                    {
                        DateTime dtExpirary = DateTime.MinValue;
                        string strException = "Not able to get SSL expirary";
                        X509Certificate cert2 = null;
                        HttpWebResponse response = null;
                        try
                        {
                            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11;
                            ServicePointManager.Expect100Continue = true;

                            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strConfigURL);
                            request.AllowAutoRedirect = false;

                            try
                            {
                                response = (HttpWebResponse)request.GetResponse();
                                X509Certificate cert = request.ServicePoint.Certificate;
                                cert2 = new X509Certificate2(cert);
                            }
                            catch (Exception ex)
                            {
                                if (request.ServicePoint.Certificate != null)
                                {
                                    X509Certificate cert = request.ServicePoint.Certificate;
                                    cert2 = new X509Certificate2(cert);
                                }
                                else
                                {
                                    fileLog.WriteLine(strConfigURL);
                                    fileLog.WriteLine(ex.Message);
                                    strException += ex.Message;
                                }
                            }
                            finally
                            {
                                if (response != null)
                                {
                                    response.Close();
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            if (string.IsNullOrEmpty(strException))
                            {
                                strException += ex.Message;
                            }
                        }

                        if (cert2 != null)
                        {
                            string cedate = cert2.GetExpirationDateString();
                            dtExpirary = Convert.ToDateTime(cedate);
                        }

                        DataRow dr = tblExpirary.NewRow();
                        dr["Asset"] = objSSLconfig.AssetName;
                        dr["Environment"] = objSSLconfig.Environment;
                        dr["URL"] = strConfigURL;
                        dr["Expirary_Date"] = dtExpirary;
                        dr["Days_to_Expire"] = (dtExpirary - System.DateTime.UtcNow).Days;
                        if (dtExpirary != DateTime.MinValue)
                        {
                            dr["Expirary_Date"] = dtExpirary;
                            dr["Days_to_Expire"] = (dtExpirary - System.DateTime.UtcNow).Days;
                            dr["Exception"] = "";
                        }
                        else
                        {
                            dr["Exception"] = strException;
                        }
                        tblExpirary.Rows.Add(dr);
                    }
                }

                string txttableHTML = "<table  border=\"1\"";
                txttableHTML += "<tr><th>Asset</th><th>Environment</th><th>URL</th><th>Expirary Date</th><th>Days to Expire</th></tr>";

                tblExpirary.DefaultView.Sort = "Days_to_Expire asc";
                tblExpirary = tblExpirary.DefaultView.ToTable();

                foreach (DataRow dr in tblExpirary.Rows)
                {
                    DateTime dtExpiraryDate = Convert.ToDateTime(dr["Expirary_Date"]);

                    if (dtExpiraryDate > DateTime.MinValue)
                    {
                        //30 days expirary, yellow color
                        if (dtExpiraryDate < DateTime.Now.AddDays(30))
                        {
                            txttableHTML += "<tr style=\"background-color:yellow\">";
                        }
                        else if (dtExpiraryDate < DateTime.Now.AddDays(7))//7 days expirary red color
                        {
                            txttableHTML += "<tr style=\"background-color:red\">";
                        }
                        else
                        {
                            txttableHTML += "<tr style=\"background-color:greenyellow\">";
                        }
                    }
                    else
                    {
                        txttableHTML += "<tr style=\"background-color:red\">";
                    }

                    txttableHTML += "<td>"; txttableHTML += dr["Asset"]; txttableHTML += "</td>";
                    txttableHTML += "<td>"; txttableHTML += dr["Environment"]; txttableHTML += "</td>";
                    txttableHTML += "<td>"; txttableHTML += dr["URL"]; txttableHTML += "</td>";
                    if (dtExpiraryDate != DateTime.MinValue)
                    {
                        txttableHTML += "<td>"; txttableHTML += dtExpiraryDate.ToString(); txttableHTML += "</td>";
                        txttableHTML += "<td>"; txttableHTML += (dtExpiraryDate - System.DateTime.UtcNow).Days.ToString(); txttableHTML += "</td>";
                        txttableHTML += "</tr>";
                    }
                    else
                    {
                        txttableHTML += "<td>"; txttableHTML += dr["Exception"]; txttableHTML += "</td>";
                        txttableHTML += "<td>"; txttableHTML += ""; txttableHTML += "</td>";
                        txttableHTML += "</tr>";
                    }
                }

                Email objEmail = new Email();
                objEmail.to = objSSLConfigs.AlertEMails.Trim();
                objEmail.subject = objSSLConfigs.AlertEMailSubject.Trim();
                objEmail.body = objSSLConfigs.AlertEMailBody + "\r\n" + txttableHTML;
                objEmail.SendEmail();
            }
            catch (Exception ex)
            {
                fileLog.WriteLine("Exception for Line " + CurrentLine + " Exception is =>" + ex.Message);
            }
            finally
            {
                fileLog.WriteLine("CheckSSLAndAlert completed => " + DateTime.UtcNow.ToString() + " time taken:" + watch.ElapsedMilliseconds + " Milliseconds.");
                fileLog.Close();
            }
        }

        public static void CheckLogFilesForSpecificErrorsFromLastCheckedLine(LogFileErrorConfig objLogFileErrorConfig)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            var watch = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                string strEmailMessage = "";

                foreach (string logFilePath in objLogFileErrorConfig.LogFilePaths.LogFilePath)
                {
                    string[] delimiter = new string[1] { '\t'.ToString() };
                    delimiter[0] = System.Environment.NewLine;

                    string[] fileRecords = Utils.GetFileRecords(logFilePath);

                    int LastCheckedLineNumber = 0;

                    if (!String.IsNullOrEmpty(objLogFileErrorConfig.LastCheckedLineNumber))
                    {
                        Int32.TryParse(objLogFileErrorConfig.LastCheckedLineNumber, out LastCheckedLineNumber);
                    }

                    if (fileRecords != null && fileRecords.Length > 0)
                    {
                        string msg = "";
                        for (int irecordstart = LastCheckedLineNumber + 1; irecordstart < fileRecords.Length; irecordstart++)
                        {
                            foreach (string strError in objLogFileErrorConfig.ErrorMessagesToSearch.ErrorMessageToSearch)
                            {
                                if (fileRecords[irecordstart].Contains(strError))
                                {
                                    msg += "------------------------------------------------------------------------------------------------\r\n";
                                    msg += strError + " found in =>\r\n" + fileRecords[irecordstart];
                                }
                            }
                        }

                        //mark the line number so that next time it will search in new messages and not in old
                        objLogFileErrorConfig.LastCheckedLineNumber = fileRecords.Length.ToString();

                        if (msg.Length > 0)
                        {
                            strEmailMessage = logFilePath + " MSG:" + msg + "\r\n";
                        }
                        else
                        {
                            // fileLog.WriteLine("No Errors found in  " + logFilePath);
                        }
                    }
                }

                if (strEmailMessage.Length > 0)
                {
                    Email objEmail = new Email();
                    objEmail.to = objLogFileErrorConfig.AlertEMails.Trim();
                    objEmail.subject = objLogFileErrorConfig.AlertEMailSubject.Trim();
                    objEmail.body = objLogFileErrorConfig.AlertEMailBody + "\r\n" + strEmailMessage;
                    objEmail.SendEmail();
                }
            }
            catch (Exception ex)
            {
                //fileLog.WriteLine(ex.Message);
                Logger.LogError(FUNC_NAME + ex);
            }

            Logger.LogInfo("CheckLogFilesForSpecificErrors Completed => " + DateTime.UtcNow.ToString() + " time taken:" + watch.ElapsedMilliseconds + " Milliseconds");
        }

        public static StreamWriter GetLogFileHandle(String FileName)
        {
            string LogFilePath = "";
            try
            {
                //create logfile directory if not exists
                if (!System.IO.Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + "LogFiles"))
                {
                    System.IO.Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + "LogFiles");
                }
                LogFilePath = AppDomain.CurrentDomain.BaseDirectory + "LogFiles\\" + FileName;
                if (System.IO.File.Exists(LogFilePath))
                {
                    long length = new System.IO.FileInfo(LogFilePath).Length / (1024 * 1024); //MB

                    if (length > 0)//if file is around 1 MB then create another file.
                    {
                        File.Copy(LogFilePath, AppDomain.CurrentDomain.BaseDirectory + "LogFiles\\" + FileName + System.DateTime.UtcNow.ToFileTimeUtc());
                        File.Delete(LogFilePath);
                    }
                }

                StreamWriter swFileLog = new StreamWriter(LogFilePath, true);
                swFileLog.AutoFlush = true;

                return swFileLog;
            }
            catch
            {
                return new StreamWriter(LogFilePath, true); ;
            }
        }

        public static PingReply PingServer(string serverAddress)
        {
            PingReply objPingReply = null;

            try
            {
                var ping = new Ping();

                for (int iRetry = 0; iRetry < 5; iRetry++)
                {
                    objPingReply = ping.Send(serverAddress, 15 * 1000);

                    if (objPingReply.Status == IPStatus.Success)
                    {
                        return objPingReply;
                    }
                    else
                    {
                        //sleep for some time and check again
                        System.Threading.Thread.Sleep(3000);
                    }
                }

                return objPingReply;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void PingServerAndAlertIfDown(ServerConfig objServerConfig)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo("Started:" + FUNC_NAME);

            try
            {
                string AlertMessages = string.Empty;

                foreach (string objserverAddress in objServerConfig.ServerAddress.PhysicalAddress)
                {
                    var ping = new Ping();
                    PingReply reply = PingServer(objserverAddress);
                    if (reply.Status != IPStatus.Success)
                    {
                        if (reply.Status != IPStatus.Success)
                        {
                            AlertMessages += "System/Server is not accessible " + objserverAddress + " status :" + reply.Status.ToString();
                            AlertMessages += "\r\n";
                        }
                    }
                }

                //send alert.
                if (!string.IsNullOrEmpty(AlertMessages))
                {
                    Email objemail = new Email();
                    objemail.body = objServerConfig.AlertEMailBody + "\r\n" + AlertMessages;
                    objemail.subject = objServerConfig.AlertEMailSubject;
                    objemail.to = objServerConfig.AlertEMails;
                    objemail.SendEmail();
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
        }

        public static DayOfWeek GetDayOfWeek(String strDayName)
        {
            switch (strDayName.ToLower())
            {
                case "sunday":
                    return DayOfWeek.Sunday;

                case "monday":
                    return DayOfWeek.Monday;

                case "tuesday":
                    return DayOfWeek.Tuesday;

                case "wednesday":
                    return DayOfWeek.Wednesday;

                case "thursday":
                    return DayOfWeek.Thursday;

                case "friday":
                    return DayOfWeek.Friday;

                case "saturday":
                    return DayOfWeek.Saturday;
            }

            return DayOfWeek.Sunday;//default
        }

        public static DateTime GetNextWeekDatetimeFromGivenDate(DateTime dt, string strWeekDayAndTime)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            DateTime dtGetNextWeekDayDateTime = DateTime.MinValue;
            Logger.LogInfo("Started:" + FUNC_NAME);

            try
            {
                string strNextWeekDay = strWeekDayAndTime.Split(',')[0];
                string strStartTime = strWeekDayAndTime.Split(',')[1];

                DayOfWeek ExceptionStartDay = GetDayOfWeek(strNextWeekDay);

                int addDays = (((int)ExceptionStartDay - (int)dt.DayOfWeek + 7) % 7);
                dtGetNextWeekDayDateTime = dt.AddDays(addDays);

                int hours = Int32.Parse(strStartTime.Split(':')[0]);
                int minutes = Int32.Parse(strStartTime.Split(':')[1]);
                int seconds = Int32.Parse(strStartTime.Split(':')[2]);
                TimeSpan ts = new TimeSpan(Int32.Parse(strStartTime.Split(':')[0]), Int32.Parse(strStartTime.Split(':')[1]), Int32.Parse(strStartTime.Split(':')[2]));
                dtGetNextWeekDayDateTime = dtGetNextWeekDayDateTime + ts;
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }

            return dtGetNextWeekDayDateTime;
        }

        private static bool CanSkipJobForNow(string DoNotRunBetweenThisTimeUTC)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            bool CanSkipJobForNow = false;

            try
            {
                if (String.IsNullOrEmpty(DoNotRunBetweenThisTimeUTC))
                    return false;

                DateTime now = DateTime.UtcNow;
                now = new DateTime(now.Year, now.Month, now.Day, 0, 0, 0);
                DateTime dtNextExceptionStart = GetNextWeekDatetimeFromGivenDate(now, DoNotRunBetweenThisTimeUTC.Split('-')[0]);
                DateTime dtNextExceptionEnd = GetNextWeekDatetimeFromGivenDate(new DateTime(dtNextExceptionStart.Year, dtNextExceptionStart.Month, dtNextExceptionStart.Day, 0, 0, 0), DoNotRunBetweenThisTimeUTC.Split('-')[1]);

                if (DateTime.UtcNow > dtNextExceptionStart && DateTime.UtcNow < dtNextExceptionEnd)
                {
                    CanSkipJobForNow = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
            return CanSkipJobForNow;
        }

        public static void CheckServerStatQueryAndAlert(ServerStatConfig objServerStatConfig)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo("Started:" + FUNC_NAME + " " + objServerStatConfig.PhysicalAddress);

            if (CanSkipJobForNow(objServerStatConfig.DoNotRunBetweenThisTimeUTC))
            {
                Logger.LogInfo("Skiping:" + FUNC_NAME + " " + objServerStatConfig.PhysicalAddress);
                return;
            }

            StreamWriter ServerStatfileLog = RSAAlert.AssetWise.Common.GetLogFileHandle("ServerStat" + ".log");

            try
            {
                //first ping server and check if its available

                SystemCheck objsystemcheck = new SystemCheck();
                objsystemcheck.computerName = objServerStatConfig.PhysicalAddress;
                objsystemcheck.userid = objServerStatConfig.User;
                objsystemcheck.password = RSAAlert.AssetWise.StringCipher.Decrypt(objServerStatConfig.Password.Trim(), "keyforrsa");

                //Check CPU

                if (objsystemcheck.GetRAMStats())
                {
                    List<KeyValuePair<String, String>> alertInfo = new List<KeyValuePair<String, String>>();

                    Logger.LogInfo("Server Address" + " " + objServerStatConfig.PhysicalAddress);
                    Logger.LogInfo("Total CPU Memory (GB): " + Math.Round(objsystemcheck.TotalVisibleMemorySize_GB, 2).ToString());
                    Logger.LogInfo("Free CPU Memory (GB):  " + Math.Round(objsystemcheck.FreePhysicalMemory_GB, 2).ToString());
                    Logger.LogInfo("Used CPU Memory (GB):  " + Math.Round(objsystemcheck.UsedPhysicalMemory_GB, 2).ToString());
                    Logger.LogInfo("Percentage CPU used(" + objServerStatConfig.PhysicalAddress.Trim() + "):   " + Math.Round(objsystemcheck.PerCentUsedMemory, 2).ToString());

                    //Server#Name#Datetime#Total#Consumed
                    //we can save to DB in future...
                    ServerStatfileLog.WriteLine(objServerStatConfig.PhysicalAddress + "#"
                                               + "CPU" + "#"
                                               + DateTime.Now.ToUniversalTime() + "#"
                                               + Math.Round(objsystemcheck.TotalVisibleMemorySize_GB, 2) * 1024 + "#"
                                               + Math.Round(objsystemcheck.UsedPhysicalMemory_GB, 2) * 1024
                                               );

                    if (objsystemcheck.PerCentUsedMemory > Convert.ToDouble(objServerStatConfig.CPUAlertCondition))
                    {
                        alertInfo.Add(new KeyValuePair<String, String>("Server Address:        ", objServerStatConfig.PhysicalAddress));
                        alertInfo.Add(new KeyValuePair<String, String>("Total CPU Memory (GB): ", Math.Round(objsystemcheck.TotalVisibleMemorySize_GB, 2).ToString()));
                        alertInfo.Add(new KeyValuePair<String, String>("Free CPU Memory (GB):  ", Math.Round(objsystemcheck.FreePhysicalMemory_GB, 2).ToString()));
                        alertInfo.Add(new KeyValuePair<String, String>("Used CPU Memory (GB):  ", Math.Round(objsystemcheck.UsedPhysicalMemory_GB, 2).ToString()));
                        alertInfo.Add(new KeyValuePair<String, String>("Percentage CPU used:   ", Math.Round(objsystemcheck.PerCentUsedMemory, 2).ToString()));
                    }

                    if (alertInfo.Count > 0)
                    {
                        SendServerStatAlert(objServerStatConfig, alertInfo, "CPU_USAGE");
                    }
                }

                if (objsystemcheck.GetDiskstats())
                {
                    List<KeyValuePair<String, String>> alertInfo = new List<KeyValuePair<String, String>>();

                    foreach (DiskSpace objDiskSpaceStat in objsystemcheck.lstDiskSpace)
                    {
                        Logger.LogInfo("Server Address:   " + objServerStatConfig.PhysicalAddress);
                        Logger.LogInfo("Drive Name:       " + objDiskSpaceStat.caption);
                        Logger.LogInfo("Size_GB:          " + Math.Round(objDiskSpaceStat.size_GB, 2).ToString());
                        Logger.LogInfo("Freespace_GB:     " + Math.Round(objDiskSpaceStat.freespace_GB, 2).ToString());
                        Logger.LogInfo("PerCentUsed:      " + Math.Round(objDiskSpaceStat.PerCentUsed, 2).ToString());

                        //Server#Name#Datetime#Total#Consumed
                        //we can save to DB in future...
                        ServerStatfileLog.WriteLine(objServerStatConfig.PhysicalAddress + "#"
                                                   + "Drive:" + objDiskSpaceStat.caption + "#"
                                                   + DateTime.Now.ToUniversalTime() + "#"
                                                   + Math.Round(objDiskSpaceStat.size_GB, 2) * 1024 + "#"
                                                   + Math.Round((objDiskSpaceStat.size_GB - objDiskSpaceStat.freespace_GB), 2) * 1024
                                                   );

                        if (objDiskSpaceStat.PerCentUsed > Convert.ToDouble(objServerStatConfig.DiskAlertCondition))
                        {
                            alertInfo.Add(new KeyValuePair<String, String>("Drive Name", objDiskSpaceStat.caption));
                            alertInfo.Add(new KeyValuePair<String, String>("Size_GB", Math.Round(objDiskSpaceStat.size_GB, 2).ToString()));
                            alertInfo.Add(new KeyValuePair<String, String>("Freespace_GB", Math.Round(objDiskSpaceStat.freespace_GB, 2).ToString()));
                            alertInfo.Add(new KeyValuePair<String, String>("PerCentUsed", Math.Round(objDiskSpaceStat.PerCentUsed, 2).ToString()));
                        }
                    }
                    if (alertInfo.Count > 0)
                    {
                        SendServerStatAlert(objServerStatConfig, alertInfo, "DISK_USAGE");
                    }
                }

                foreach (Process objProcess in objServerStatConfig.Processes.Process)
                {
                    ProcessStat objProcessStat = new ProcessStat();
                    objProcessStat.name = objProcess.ProcessName;
                    objProcessStat.alertCondition = objProcess.AlertCondition;
                    objsystemcheck.lstProcessStat.Add(objProcessStat);
                }

                if (objsystemcheck.GetProcessStats())
                {
                    List<KeyValuePair<String, String>> alertInfo = new List<KeyValuePair<String, String>>();

                    foreach (ProcessStat objProcessStat in objsystemcheck.lstProcessStat)
                    {
                        Logger.LogInfo("Server Address" + " " + objServerStatConfig.PhysicalAddress);
                        Logger.LogInfo("Process Name" + " " + objProcessStat.name);
                        Logger.LogInfo("Process Memory_size_MB" + " " + Math.Round(objProcessStat.Memoru_size_MB, 2).ToString());

                        //Server#Name#Datetime#Total#Consumed
                        //we can save to DB in future...
                        ServerStatfileLog.WriteLine(objServerStatConfig.PhysicalAddress + "#"
                                                   + objProcessStat.name + "#"
                                                   + DateTime.Now.ToUniversalTime() + "#"
                                                   + 0 + "#"
                                                   + Math.Round(objProcessStat.Memoru_size_MB, 2)
                                                   );

                        if (objProcessStat.Memoru_size_MB > Convert.ToDouble(objProcessStat.alertCondition) || !objProcessStat.IsRunning)
                        {
                            alertInfo.Add(new KeyValuePair<String, String>("Server Address", objServerStatConfig.PhysicalAddress));
                            alertInfo.Add(new KeyValuePair<String, String>("Process Name", objProcessStat.name));
                            if (objProcessStat.IsRunning)
                            {
                                alertInfo.Add(new KeyValuePair<String, String>("Process Memory_size_MB", Math.Round(objProcessStat.Memoru_size_MB, 2).ToString()));
                            }
                            else
                            {
                                alertInfo.Add(new KeyValuePair<String, String>("Process Memory_size_MB", "Process is not running."));
                            }
                        }
                    }

                    //send alert
                    if (alertInfo.Count > 0)
                    {
                        SendServerStatAlert(objServerStatConfig, alertInfo, "PROCESS_USAGE");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
            finally
            {
                ServerStatfileLog.Close();
            }
        }

        public static void SendServerStatAlert(ServerStatConfig objServerStatConfig, List<KeyValuePair<String, String>> alertInfo, string AlertName)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo("Started:" + FUNC_NAME);

            try
            {
                DataTable dt = new DataTable(AlertName);
                dt.Columns.Add("Label", typeof(String));
                dt.Columns.Add("alertInformation", typeof(String));
                foreach (KeyValuePair<string, string> entry in alertInfo)
                {
                    DataRow dr = dt.NewRow();
                    dr[0] = entry.Key;
                    dr[1] = entry.Value;
                    dt.Rows.Add(dr);
                }

                DataSet ds = new DataSet();
                ds.Tables.Add(dt);

                Email objemail = new Email();
                objemail.body = objServerStatConfig.AlertEMailBody;
                objemail.subject = objServerStatConfig.AlertEMailSubject + " " + objServerStatConfig.PhysicalAddress;
                objemail.to = objServerStatConfig.AlertEMails;
                objemail.SendEmail(ds);
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
        }
    }

    public static class StringCipher
    {
        // This constant is used to determine the keysize of the encryption algorithm in bits.
        // We divide this by 8 within the code below to get the equivalent number of bytes.
        private const int Keysize = 256;

        // This constant determines the number of iterations for the password bytes generation function.
        private const int DerivationIterations = 1000;

        public static string Encrypt(string plainText, string passPhrase)
        {
            if (string.IsNullOrEmpty(plainText))
                return plainText;
            // Salt and IV is randomly generated each time, but is preprended to encrypted cipher text
            // so that the same Salt and IV values can be used when decrypting.
            var saltStringBytes = Generate256BitsOfRandomEntropy();
            var ivStringBytes = Generate256BitsOfRandomEntropy();
            var plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            using (var password = new Rfc2898DeriveBytes(passPhrase, saltStringBytes, DerivationIterations))
            {
                var keyBytes = password.GetBytes(Keysize / 8);
                using (var symmetricKey = new RijndaelManaged())
                {
                    symmetricKey.BlockSize = 256;
                    symmetricKey.Mode = CipherMode.CBC;
                    symmetricKey.Padding = PaddingMode.PKCS7;
                    using (var encryptor = symmetricKey.CreateEncryptor(keyBytes, ivStringBytes))
                    {
                        using (var memoryStream = new MemoryStream())
                        {
                            using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                            {
                                cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
                                cryptoStream.FlushFinalBlock();
                                // Create the final bytes as a concatenation of the random salt bytes, the random iv bytes and the cipher bytes.
                                var cipherTextBytes = saltStringBytes;
                                cipherTextBytes = cipherTextBytes.Concat(ivStringBytes).ToArray();
                                cipherTextBytes = cipherTextBytes.Concat(memoryStream.ToArray()).ToArray();
                                memoryStream.Close();
                                cryptoStream.Close();
                                return Convert.ToBase64String(cipherTextBytes);
                            }
                        }
                    }
                }
            }
        }

        public static string Decrypt(string cipherText, string passPhrase)
        {
            if (string.IsNullOrEmpty(cipherText))
                return cipherText;
            // Get the complete stream of bytes that represent:
            // [32 bytes of Salt] + [32 bytes of IV] + [n bytes of CipherText]
            var cipherTextBytesWithSaltAndIv = Convert.FromBase64String(cipherText);
            // Get the saltbytes by extracting the first 32 bytes from the supplied cipherText bytes.
            var saltStringBytes = cipherTextBytesWithSaltAndIv.Take(Keysize / 8).ToArray();
            // Get the IV bytes by extracting the next 32 bytes from the supplied cipherText bytes.
            var ivStringBytes = cipherTextBytesWithSaltAndIv.Skip(Keysize / 8).Take(Keysize / 8).ToArray();
            // Get the actual cipher text bytes by removing the first 64 bytes from the cipherText string.
            var cipherTextBytes = cipherTextBytesWithSaltAndIv.Skip((Keysize / 8) * 2).Take(cipherTextBytesWithSaltAndIv.Length - ((Keysize / 8) * 2)).ToArray();

            using (var password = new Rfc2898DeriveBytes(passPhrase, saltStringBytes, DerivationIterations))
            {
                var keyBytes = password.GetBytes(Keysize / 8);
                using (var symmetricKey = new RijndaelManaged())
                {
                    symmetricKey.BlockSize = 256;
                    symmetricKey.Mode = CipherMode.CBC;
                    symmetricKey.Padding = PaddingMode.PKCS7;
                    using (var decryptor = symmetricKey.CreateDecryptor(keyBytes, ivStringBytes))
                    {
                        using (var memoryStream = new MemoryStream(cipherTextBytes))
                        {
                            using (var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                            {
                                var plainTextBytes = new byte[cipherTextBytes.Length];
                                var decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
                                memoryStream.Close();
                                cryptoStream.Close();
                                return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
                            }
                        }
                    }
                }
            }
        }

        private static byte[] Generate256BitsOfRandomEntropy()
        {
            var randomBytes = new byte[32]; // 32 Bytes will give us 256 bits.
            using (var rngCsp = new RNGCryptoServiceProvider())
            {
                // Fill the array with cryptographically secure random bytes.
                rngCsp.GetBytes(randomBytes);
            }
            return randomBytes;
        }

        public static string RemoveWhiteSpaceNewLine(string str)
        {
            return str.Replace("\r\n", "").Trim().Replace(" ", "").Trim();
        }

        public static string RemoveNewLine(string str)
        {
            return str.Replace("\r\n", "").Trim();
        }
    }
}