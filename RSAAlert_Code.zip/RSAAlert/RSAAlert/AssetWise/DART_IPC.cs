﻿using RSAAlert.XMLClasses;
using System;
using System.IO;
using RSAAlert.Common;
namespace RSAAlert.AssetWise
{
    public static class DART_IPC
    {
        private static readonly string CLASSNAME = System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name + ".";
        public static void CheckLogFiles(LogFileErrorConfig objLogFileErrorConfig)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            var watch = System.Diagnostics.Stopwatch.StartNew();
            StreamWriter fileLog = RSAAlert.AssetWise.Common.GetLogFileHandle(objLogFileErrorConfig.AssetName + "-" + objLogFileErrorConfig.Environment + ".log");

            fileLog.WriteLine("LogTimerDARTIPC_elapsed started => " + DateTime.UtcNow.ToString());
            Logger.LogInfo(FUNC_NAME + " Started");

            try
            {
                string strEmailMessage = "";

                foreach (string logFilePath in objLogFileErrorConfig.LogFilePaths.LogFilePath)
                {
                    string[] delimiter = new string[1] { '\t'.ToString() };
                    delimiter[0] = System.Environment.NewLine;

                    string[] fileRecords = Utils.GetFileRecords(logFilePath);

                    if (fileRecords != null && fileRecords.Length > 0)
                    {
                        bool bStillissue = false;
                        DateTime dtErrorTime = DateTime.MinValue, dtLastErrorTime = DateTime.MinValue;
                        string msg = "";

                        foreach (string str in fileRecords)
                        {
                            if (!bStillissue && str.Contains("This will require a restart"))
                            {
                                bStillissue = true;
                                string[] strvals = str.Split(',');
                                try
                                {
                                    dtErrorTime = Convert.ToDateTime(strvals[0]);
                                }
                                catch { }
                            }
                            if (bStillissue && (str.Contains("Starting Server") || str.Contains("[system] INFO - SQL executed in:")))
                            {
                                bStillissue = false;
                            }
                        }

                        //find exact time it was down
                        if (bStillissue)
                        {
                            foreach (string str in fileRecords)
                            {
                                if (str.Contains("[system] ERROR - Cannot connect to primary database"))
                                {
                                    string[] strvals = str.Split(',');

                                    try
                                    {
                                        dtLastErrorTime = Convert.ToDateTime(strvals[0]);
                                    }
                                    catch { }
                                }
                            }

                            if (dtErrorTime != DateTime.MinValue && dtLastErrorTime != DateTime.MinValue && dtErrorTime != dtLastErrorTime)
                            {
                                System.TimeSpan diff1 = dtLastErrorTime.Subtract(dtErrorTime);
                                msg = "Not able to connect to DB since " + diff1.TotalMinutes + " minutes. Error time before last successful connection " + dtErrorTime.ToString() + " Last error time " + dtLastErrorTime.ToString();
                            }
                        }

                        if (bStillissue)
                        {
                            strEmailMessage = logFilePath + " MSG:" + msg + "\r\n";
                        }
                        else
                        {
                            fileLog.WriteLine("No Issue found for DART IPC for " + logFilePath);
                        }
                    }
                }

                if (strEmailMessage.Length > 0)
                {
                    Email objEmail = new Email();
                    objEmail.to = objLogFileErrorConfig.AlertEMails.Trim(); 
                    objEmail.subject = objLogFileErrorConfig.AlertEMailSubject.Trim();
                    objEmail.body = objLogFileErrorConfig.AlertEMailBody + "\r\n" + "Error - This will require a restart is found in log files " + strEmailMessage + " and server is not restarted after that and no evidence of any successful connection. Please check log file manually and take action accordingly.";
                    objEmail.SendEmail();
                }
            }
            catch (Exception ex)
            {
                fileLog.WriteLine(ex.Message);
                Logger.LogError(FUNC_NAME + ex);
            }
            finally
            {
                fileLog.WriteLine("LogTimerDARTIPC_elapsed Completed => " + DateTime.UtcNow.ToString() + " time taken:" + watch.ElapsedMilliseconds  + " Milliseconds");
                fileLog.WriteLine("--------------------------------------------------------------------------------------------------");
                fileLog.Close();
                Logger.LogInfo(FUNC_NAME + " Completed" + " time taken:" + watch.ElapsedMilliseconds + " Milliseconds");
            }
        }
    }
}