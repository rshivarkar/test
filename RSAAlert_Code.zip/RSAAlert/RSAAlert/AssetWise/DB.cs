﻿using Oracle.DataAccess.Client;
using RSAAlert.Common;
using RSAAlert.XMLClasses;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace RSAAlert.AssetWise
{
    public class DB
    {
        private static readonly string CLASSNAME = System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name + ".";

        private enum ServerType
        {
            ORACLE,
            SQLSERVER
        };

        private string ConnectionServer;
        private string username;
        private string password;
        private string SQLDatabase;
        private ServerType serverType;

        public DB(string ConnectionServer, string username, string password, string SQLDatabase, string strServerType)
        {
            this.ConnectionServer = RSAAlert.AssetWise.StringCipher.RemoveNewLine(ConnectionServer);
            this.username = RSAAlert.AssetWise.StringCipher.RemoveNewLine(username);
            this.password = RSAAlert.AssetWise.StringCipher.RemoveNewLine(password);

            this.SQLDatabase = SQLDatabase;
            if (strServerType.ToLower().Contains("oracle"))
            {
                this.serverType = ServerType.ORACLE;
            }
            else if ((strServerType.ToLower().Contains("sql")))
            {
                this.serverType = ServerType.SQLSERVER;
            }
        }

        private string GetConnectionString()
        {
            try
            {
                string strEncryptedPAssword = "";

                if (IsConnectionMarkedAsBad())
                {
                    throw new System.ArgumentException("Connection is marked as bad, please check.", "DBConnectError");
                }
                try
                {
                    strEncryptedPAssword = RSAAlert.AssetWise.StringCipher.Decrypt(password, "keyforrsa");
                }
                catch
                {
                    throw new System.ArgumentException("Password is not getting peoperly decrypted", "PasswordError");
                }

                if (this.serverType == ServerType.ORACLE)
                {
                    return @"Data Source=" + ConnectionServer + "; " +
                       " User ID=" + username + ";Max Pool Size=256;password=" + strEncryptedPAssword + "";
                }
                else if (this.serverType == ServerType.SQLSERVER)
                {
                    return @"server=" + ConnectionServer + "; database=" + SQLDatabase + "; UID=" + username + "; PWD=" + strEncryptedPAssword + ";Connect Timeout=400; pooling='true'; Max Pool Size=200";
                }

                throw new System.ArgumentException("Servertype in config file is not set properly", "Servertype");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void RunDBQueries(DBConfig objDBConfig)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo(FUNC_NAME);
            DataSet dsAlertDataset = new DataSet();

            try
            {
                if (objDBConfig.ServerType.Equals("Oracle"))
                {
                    foreach (Query objQuery in objDBConfig.Queries.Query)
                    {
                        DataTable dt = RunDBQueries(objQuery);
                        if (string.IsNullOrEmpty(objQuery.AlertCondition))
                        {
                            dsAlertDataset.Tables.Add(dt);
                        }
                        else
                        {
                            if (dt.Select(objQuery.AlertCondition).Length > 0)
                            {
                                DataTable dtAlert = dt.Select(objQuery.AlertCondition).CopyToDataTable();
                                if (dtAlert != null && dtAlert.Rows.Count > 0)
                                {
                                    dsAlertDataset.Tables.Add(dtAlert);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);

                //send alert for exception
            }
            finally
            {
                if (dsAlertDataset != null && dsAlertDataset.Tables.Count > 0)
                {
                    Email objEmail = new Email();
                    objEmail.to = objDBConfig.AlertEMails;
                    objEmail.subject = objDBConfig.AlertEMailSubject;
                    objEmail.body = "";
                    objEmail.SendEmail(dsAlertDataset);
                }
            }
        }

        public void RunDBQueriesAndAlert(Query objQuery)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo(FUNC_NAME);
            DataSet dsAlertDataset = new DataSet();

            try
            {
                DataTable dt = RunDBQueries(objQuery);
                if (dt != null && dt.Rows.Count > 0)
                {
                    if (string.IsNullOrEmpty(objQuery.AlertCondition))
                    {
                        dsAlertDataset.Tables.Add(dt);
                    }
                    else
                    {
                        if (dt.Select(objQuery.AlertCondition).Length > 0)
                        {
                            DataTable dtAlert = dt.Select(objQuery.AlertCondition).CopyToDataTable();
                            if (dtAlert != null && dtAlert.Rows.Count > 0)
                            {
                                dtAlert.TableName = dt.TableName;
                                dsAlertDataset.Tables.Add(dtAlert);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
            finally
            {
                if (dsAlertDataset != null && dsAlertDataset.Tables.Count > 0)
                {
                    Email objEmail = new Email();
                    objEmail.to = objQuery.AlertEMails;
                    objEmail.subject = objQuery.AlertEMailSubject;
                    objEmail.body = "";
                    objEmail.SendEmail(dsAlertDataset);
                }
            }
        }

        public DataTable RunDBQueries(Query objDBQuery)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo(FUNC_NAME);

            DataTable dt = new DataTable();

            try
            {
                string queryText = RSAAlert.AssetWise.StringCipher.RemoveNewLine(objDBQuery.QueryText);

                if (this.serverType == ServerType.ORACLE)
                {
                    using (OracleConnection conn = new OracleConnection(this.GetConnectionString()))
                    {
                        //Open connection
                        Logger.LogInfo(FUNC_NAME + "Opening DB connection");
                        conn.Open();

                        OracleCommand command = new OracleCommand(queryText, conn);
                        command.CommandTimeout = 300;//set for 300 seconds
                        Logger.LogInfo("Query Started:" + objDBQuery.QueryName);
                        int rows = 0;

                        var watch = System.Diagnostics.Stopwatch.StartNew();

                        using (OracleDataReader rdr = command.ExecuteReader())
                        {
                            if (rdr.HasRows)
                            {
                                dt.Load(rdr);
                                rows = dt.Rows.Count;
                                if (rows == 1 && dt.Columns.Contains("COUNT"))
                                {
                                    int count = 0;
                                    if (dt.Rows[0]["COUNT"] != DBNull.Value)
                                    {
                                        Int32.TryParse(dt.Rows[0]["COUNT"].ToString(), out count);
                                        Logger.LogInfo("count for query:" + objDBQuery.QueryName + "=>" + count.ToString());
                                    }

                                }
                                dt.TableName = objDBQuery.QueryName + ":=>" + queryText;
                            }
                        }

                        Logger.LogInfo("Query Completed:" + objDBQuery.QueryName + " Rows returned:" + rows.ToString() + " time taken:" + watch.ElapsedMilliseconds  + " Milliseconds.");
                    }
                }
                else if (this.serverType == ServerType.SQLSERVER)
                {
                    using (SqlConnection conn = new SqlConnection(this.GetConnectionString()))
                    {
                        //Open connection
                        Logger.LogInfo(FUNC_NAME + "Opening DB connection");
                        conn.Open();

                        SqlCommand command = new SqlCommand(queryText, conn);
                        command.CommandTimeout = 300;//set for 300 seconds
                        Logger.LogInfo("Query Started:" + objDBQuery.QueryName);
                        int rows = 0;
                        var watch = System.Diagnostics.Stopwatch.StartNew();
                        using (SqlDataReader rdr = command.ExecuteReader())
                        {
                            if (rdr.HasRows)
                            {
                                dt.Load(rdr);
                                rows = dt.Rows.Count;
                                dt.TableName = objDBQuery.QueryName + ":=>" + queryText;
                            }
                        }

                        Logger.LogInfo("Query Completed:" + objDBQuery.QueryName + " Rows returned:" + rows.ToString() + " time taken:" + watch.ElapsedMilliseconds  + " Milliseconds.");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);

                string Message = "";
                if (ex.Message.Contains("ORA-1017") || ex.Message.Contains("password") || ex.Message.Contains("logon denied") || ex.Message.Contains("Login failed"))
                {
                    Message = "Issue with username/password , please correct those in config file and restart service.";
                    Message += "</br>";
                    Message += ex.Message;
                    Message += "</br>";

                    //Send alert of this exception.
                    Email objEmail = new Email();
                    objEmail.to = objDBQuery.AlertEMails;
                    objEmail.subject = "Issue with RSA tool or with username/password for this DB query.";
                    Message += "Exception occured while running this query: </br>" + objDBQuery.QueryText;
                    Message += "</br>" + ex.Message;
                    Message += "</br>";
                    Message += "This alert will not open connection next time but will keep sending alert message untill we fix those issues.";

                    //VERY IMPORTANT !!!!
                    //IF there is any issue with username, Password or query, it will not get executed next time, so we are saving connection string here
                    //all queries with this connection will not be run..
                    MarkConnectionAsBad();

                    objEmail.body = Message;
                    objEmail.SendEmail();
                }
               
                return null;
            }

            return dt;
        }

        public void MarkConnectionAsBad()
        {
            if (IsConnectionMarkedAsBad())//Already marked as bad return..
                return;

            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            try
            {
                StreamWriter swFileLog = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "BadConnections.txt", true);
                swFileLog.WriteLine(this.ConnectionServer);
                swFileLog.Close();
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME + ex);
            }
        }

        public bool IsConnectionMarkedAsBad()
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            bool IsConnectionMarkedAsBad = false;

            try
            {
                string[] fileRecords = Utils.GetFileRecords(AppDomain.CurrentDomain.BaseDirectory + "BadConnections.txt");

                if (fileRecords != null && fileRecords.Length > 0)
                {
                    foreach (String strConnections in fileRecords)
                    {
                        if (strConnections.ToLower().Trim().Equals(this.ConnectionServer.Trim().ToLower()))
                        {
                            IsConnectionMarkedAsBad = true;
                            return IsConnectionMarkedAsBad;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME + ex);
                IsConnectionMarkedAsBad = true;//if exception then mark it as bad.
            }

            return IsConnectionMarkedAsBad;
        }
    }
}