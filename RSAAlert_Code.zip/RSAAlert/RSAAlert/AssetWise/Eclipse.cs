﻿using RSAAlert.Common;
using RSAAlert.XMLClasses;
using System;
using System.IO;
using System.Text;

namespace RSAAlert.AssetWise
{
    internal class Eclipse
    {
        private static readonly string CLASSNAME = System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name + ".";

        public static void CheckLogFileLastModifiedFile(LogFileErrorConfig objLogFileErrorConfig)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            var watch = System.Diagnostics.Stopwatch.StartNew();

            StreamWriter fileLog = RSAAlert.AssetWise.Common.GetLogFileHandle(objLogFileErrorConfig.AssetName + "-" + objLogFileErrorConfig.Environment + ".log");
            fileLog.WriteLine("CheckLogFileLastModifiedFile started" + DateTime.UtcNow.ToString());
            Logger.LogInfo(FUNC_NAME + " Started");
            try
            {
                string strMsg = "";

                foreach (string logFilePath in objLogFileErrorConfig.LogFilePaths.LogFilePath)
                {
                    DateTime lastModified = System.IO.File.GetLastWriteTimeUtc(logFilePath);
                    DateTime dtNow = DateTime.UtcNow;
                    System.TimeSpan diff1 = dtNow.Subtract(lastModified);
                    if (diff1.Hours > 0)
                    {
                        strMsg += "Log file is not updated since last one hour, please check and restart if required=> " + logFilePath;
                        strMsg += "\r\n";
                        strMsg += ".....................................................................................................";
                        strMsg += "Last updatd log time (UTC) " + lastModified.ToString() + " Current time(UTC)" + dtNow.ToString();
                        strMsg += "\r\n";
                    }
                    else
                    {
                        fileLog.WriteLine("Eclipse Outbound service Running fine.Last updatd log time (UTC) " + lastModified.ToString() + " Current time(UTC)" + dtNow.ToString());
                    }
                }

                if (!string.IsNullOrEmpty(strMsg))
                {
                    Email objEmail = new Email();
                    objEmail.to = objLogFileErrorConfig.AlertEMails.Trim();
                    objEmail.subject = objLogFileErrorConfig.AlertEMailSubject;
                    objEmail.body = objLogFileErrorConfig.AlertEMailBody + "\r\n" + strMsg;
                    objEmail.SendEmail();
                }
            }
            catch (Exception ex)
            {
                fileLog.WriteLine(ex.Message);
                Logger.LogError(FUNC_NAME + ex);
            }
            finally
            {
                fileLog.Close();
                Logger.LogInfo(FUNC_NAME + " completed" + " time taken:" + watch.ElapsedMilliseconds + " Milliseconds.");
            }
        }

        public static void CheckQuoteServerStatus(QuoteConfig objQuoteConfig)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            var watch = System.Diagnostics.Stopwatch.StartNew();
            Logger.LogInfo(FUNC_NAME + " Started");

            try
            {
                int QuoteGenerateThresholdSeconds = objQuoteConfig.QuoteGenerateThresholdSeconds;
                int QuoteFileMinSizeBytes = objQuoteConfig.QuoteFileMinSizeBytes;
                string QuoteSites = objQuoteConfig.QuoteSites;

                string[] arraySites = QuoteSites.Split(',');
                DateTime startTime = DateTime.UtcNow;
                DateTime endTime = DateTime.UtcNow;
                string quoteSite = string.Empty;
                string quoteSite2 = string.Empty;

                StringBuilder strErrorAlert = new StringBuilder();

                for (int k = 0; k < arraySites.Length; k++)
                {
                    quoteSite = arraySites[k].Trim();

                    try
                    {
                        using (System.Net.WebClient client = new System.Net.WebClient())
                        {
                            startTime = DateTime.UtcNow;
                            byte[] file = client.DownloadData(new Uri(quoteSite));
                            endTime = DateTime.UtcNow;

                            quoteSite2 = quoteSite.Replace("http://", "");
                            quoteSite2 = quoteSite2.Substring(0, quoteSite2.IndexOf('/'));

                            Logger.LogInfo(quoteSite2 + " time taken:" + endTime.Subtract(startTime).Seconds.ToString());

                            if (endTime.Subtract(startTime).Seconds > QuoteGenerateThresholdSeconds)
                            {
                                //retry one more time to get result before alert
                                System.Threading.Thread.Sleep(5000);
                                startTime = DateTime.UtcNow;
                                file = client.DownloadData(new Uri(quoteSite));
                                endTime = DateTime.UtcNow;

                                if (endTime.Subtract(startTime).Seconds > QuoteGenerateThresholdSeconds)
                                {
                                    strErrorAlert.AppendLine("Quote generation running slow on server: " + quoteSite2);
                                   strErrorAlert.AppendLine("Quote generation has been taken " + endTime.Subtract(startTime).Seconds + " seconds which is longer than expected .. Please take immediate action.");
                                    strErrorAlert.AppendLine(quoteSite);
                                }
                            }

                            if (file.Length < QuoteFileMinSizeBytes) //If SSRS service failing to generate quote the size is 975 bytes
                            {
                                //retry before we error out.
                                System.Threading.Thread.Sleep(5000);
                                file = client.DownloadData(new Uri(quoteSite));
                                if (file.Length < QuoteFileMinSizeBytes) //If SSRS service failing to generate quote the size is 975 bytes
                                {
                                    string result = System.Text.Encoding.UTF8.GetString(file);
                                    strErrorAlert.AppendLine("Quote generation failing on server: " + quoteSite2 + "Quote generation failing on this server .. Please take immediate action");
                                    strErrorAlert.AppendLine(quoteSite);
                                    strErrorAlert.AppendLine(result);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        quoteSite2 = quoteSite.Replace("http://", "");
                        quoteSite2 = quoteSite2.Substring(0, quoteSite2.IndexOf('/'));

                        strErrorAlert.AppendLine("Quote generation thowring exception on server: " + quoteSite2 + "Quote generation thowring on this server .. Please take immediate action. ");
                        strErrorAlert.AppendLine(quoteSite);
                        strErrorAlert.AppendLine("Exception: " + ex.ToString());
                    }
                }

                if (strErrorAlert.Length > 0)
                {
                    Email objEmail = new Email();
                    objEmail.to = objQuoteConfig.AlertEMails.Trim();
                    objEmail.subject = objQuoteConfig.AlertEMailSubject;
                    objEmail.body = objQuoteConfig.AlertEMailBody + "\r\n" + strErrorAlert;
                    //objEmail.FileAttachment
                    objEmail.SendEmail();
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME + ex);
            }
            finally
            {
                Logger.LogInfo(FUNC_NAME + " completed" + " time taken:" + watch.ElapsedMilliseconds + " Milliseconds.");
            }
        }
    }
}