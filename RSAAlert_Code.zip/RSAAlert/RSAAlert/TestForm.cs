﻿using RSAAlert.Common;
using RSAAlert.WebAPI;
using RSAAlert.XMLClasses;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Net.NetworkInformation;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using System.Web.Http;
using System.Web.Http.SelfHost;
using System.IO;
using System.Net.Sockets;
using System.Net.Security;
using System.Security.Authentication;

namespace RSAAlert
{
    public partial class TestForm : Form
    {
        private static readonly string CLASSNAME =
  System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name + ".";

        public TestForm()
        {
            InitializeComponent();
        }

        private void BtnTestAllconfigs_Click(object sender, EventArgs e)
        {
          //  delete current log file
            using (var fs = new FileStream(AppDomain.CurrentDomain.BaseDirectory + "RSAAlertMain.log", FileMode.Truncate))
            {
            }

            //check config file in input folder
            Logger.LogInfo("Test Log");

            try
            {
                string[] fileEntries = System.IO.Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + "InputFiles", "*.xml");

                bool btestCalling = true;
                bool btestDBconfig = true;
                bool btestSSLconfig = true;
                bool btestLogFileconfig = true;
                bool btestServerPingConfig = true;

                var watch = System.Diagnostics.Stopwatch.StartNew();

                //if (btestCalling)
                {
                    richTextBox1.Text += "\r\n Calling Functions...started";

                    foreach (string strConfigFilePath in fileEntries)
                    {
                        if (!strConfigFilePath.Contains(txtFile.Text))
                        {
                            continue;
                        }
                        if (strConfigFilePath.Contains("DBConfig") && btestDBconfig)
                        {
                            var serializerSSL = new XmlSerializer(typeof(DBConfigs));
                            using (var reader = XmlReader.Create(strConfigFilePath))
                            {
                                DBConfigs objConfigs = (DBConfigs)serializerSSL.Deserialize(reader);
                                richTextBox1.Text += "\r\n Running for =>" + strConfigFilePath;

                                foreach (DBConfig objDbConfig in objConfigs.DBConfig)
                                {
                                    if (objDbConfig.IntervalInMinutes == -1 && objDbConfig.UTCStartTimeHour == -1)
                                    {
                                        RSAAlert.AssetWise.DB objDB = new AssetWise.DB(objDbConfig.ConnecionString, objDbConfig.DBUser, objDbConfig.DBPassword, "", objDbConfig.ServerType);

                                        foreach (Query objQuery in objDbConfig.Queries.Query)
                                        {
                                            objDB.RunDBQueriesAndAlert(objQuery);
                                        }
                                    }
                                    else
                                    {
                                        RSAAlert.AssetWise.DB objDB = new AssetWise.DB(objDbConfig.ConnecionString, objDbConfig.DBUser, objDbConfig.DBPassword, "", objDbConfig.ServerType);
                                        objDB.RunDBQueries(objDbConfig);
                                    }
                                }
                            }
                        }
                        else if (strConfigFilePath.Contains("LogFileErrorConfig") && btestLogFileconfig)
                        {
                            var serializerSSL = new XmlSerializer(typeof(LogFileErrorConfigs));
                            LogFileErrorConfigs objConfigs = new LogFileErrorConfigs();
                            using (var reader = XmlReader.Create(strConfigFilePath))
                            {
                                objConfigs = (LogFileErrorConfigs)serializerSSL.Deserialize(reader);
                               
                                richTextBox1.Text += "\r\n Running for =>" + strConfigFilePath;

                                foreach (LogFileErrorConfig objLogFileErrorConfig in objConfigs.LogFileErrorConfig)
                                {
                                    if (string.IsNullOrEmpty(objLogFileErrorConfig.CustomLogic))
                                    {
                                        RSAAlert.AssetWise.Common.CheckLogFilesForSpecificErrorsFromLastCheckedLine(objLogFileErrorConfig);
                                    }
                                    else
                                    {
                                        if (objLogFileErrorConfig.CustomLogic.Equals("DART-IPC"))
                                        {
                                            RSAAlert.AssetWise.DART_IPC.CheckLogFiles(objLogFileErrorConfig);
                                        }
                                        else if (objLogFileErrorConfig.CustomLogic.Equals("CheckLogFileLastModifiedFile"))
                                        {
                                            RSAAlert.AssetWise.Eclipse.CheckLogFileLastModifiedFile(objLogFileErrorConfig);
                                        }
                                    }
                                }

                              
                            }
                            using (var wfile = new System.IO.StreamWriter(strConfigFilePath))
                            {
                                System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(typeof(LogFileErrorConfigs));
                                writer.Serialize(wfile, objConfigs);
                            }
                                //save the 
                            //    System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(typeof(LogFileErrorConfigs));
                            //var wfile = new System.IO.StreamWriter(strConfigFilePath);
                            //writer.Serialize(wfile, objConfigs);
                            //wfile.Close();
                        }
                        else if (strConfigFilePath.Contains("SSLConfig") && btestSSLconfig)
                        {
                            var serializerSSL = new XmlSerializer(typeof(SSLConfigs));
                            using (var reader = XmlReader.Create(strConfigFilePath))
                            {
                                SSLConfigs objConfigs = (SSLConfigs)serializerSSL.Deserialize(reader);
                                richTextBox1.Text += "\r\n Running for =>" + strConfigFilePath;

                                RSAAlert.AssetWise.Common.CheckSSLAndAlert(objConfigs);
                            }
                        }
                        else if (strConfigFilePath.Contains("ServerPingConfig") && btestServerPingConfig)
                        {
                            var serializerSSL = new XmlSerializer(typeof(ServerPingConfig));
                            using (var reader = XmlReader.Create(strConfigFilePath))
                            {
                                ServerPingConfig objConfigs = (ServerPingConfig)serializerSSL.Deserialize(reader);
                                richTextBox1.Text += "\r\n Running for =>" + strConfigFilePath;

                                foreach (ServerConfig objServerConfig in objConfigs.ServerConfig)
                                {
                                    RSAAlert.AssetWise.Common.PingServerAndAlertIfDown(objServerConfig);
                                }
                            }
                        }
                        else if (strConfigFilePath.Contains("ServerStatConfigs") && btestServerPingConfig)
                        {
                            var serializerSSL = new XmlSerializer(typeof(ServerStatConfigs));
                            using (var reader = XmlReader.Create(strConfigFilePath))
                            {
                                ServerStatConfigs objConfigs = (ServerStatConfigs)serializerSSL.Deserialize(reader);
                                richTextBox1.Text += "\r\n Running for =>" + strConfigFilePath;

                                foreach (ServerStatConfig objServerStatConfig in objConfigs.ServerStatConfig)
                                {
                                    //foreach (Query objQuery in objServerStatConfig.Queries.Query)
                                    {
                                        RSAAlert.AssetWise.Common.CheckServerStatQueryAndAlert(objServerStatConfig);
                                    }
                                }
                            }
                        }
                        else if (strConfigFilePath.Contains("QuoteConfig_Eclipse_Alert") && btestServerPingConfig)
                        {
                            var serializerSSL = new XmlSerializer(typeof(QuoteConfigs));
                            using (var reader = XmlReader.Create(strConfigFilePath))
                            {
                                QuoteConfigs objQuoteConfigs = (QuoteConfigs)serializerSSL.Deserialize(reader);
                                richTextBox1.Text += "\r\n Running for =>" + strConfigFilePath;

                                foreach (QuoteConfig objQuoteConfig in objQuoteConfigs.QuoteConfig)
                                {
                                    RSAAlert.AssetWise.Eclipse.CheckQuoteServerStatus(objQuoteConfig);
                                }
                            }
                        }
                        else
                        {
                            richTextBox1.Text += "\r\n Not supported check filename format : " + strConfigFilePath;
                        }
                    }

                    richTextBox1.Text += "\r\n Calling Functions...Comleted";
                }

                richTextBox1.Text += "\r\n. Log File Messages";
                string[] fileRecords = Utils.GetFileRecords(AppDomain.CurrentDomain.BaseDirectory + "RSAAlertMain.log");

                if (fileRecords != null && fileRecords.Length > 0)
                {
                    foreach (String strlog in fileRecords)
                    {
                        richTextBox1.Text += "\r\n" + strlog;
                    }
                }

                richTextBox1.Text += "\r\n Time Taken for all tests to run =>" + watch.ElapsedMilliseconds + " Milliseconds.";
            }
            catch (Exception ex)
            {
                richTextBox1.Text += "\r\n" + ex.Message;
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            Application.DoEvents();
        }

        private void btnCheckSingleSSL_Click(object sender, EventArgs e)
        {
            List<string> strURLs = new List<string>();
            strURLs.Add("https://mpo.houston.hp.com/");
            strURLs.Add("https://optimus.austin.hp.com/optimus/");

            foreach(string strURL in strURLs)
            {
                SSLCheck(strURL);
            }
        }

        private void SSLCheck(String URL)
        {
            DateTime dtExpirary = DateTime.MinValue;
            string strException = "Not able to get SSL expirary";
            X509Certificate cert2 = null;
            HttpWebResponse response = null;
            try
            {
                

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.AllowAutoRedirect = false;
                ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11;
                ServicePointManager.DefaultConnectionLimit = 9999;
                const SslProtocols _Tls12 = (SslProtocols)0x00000C00;
                const SecurityProtocolType Tls12 = (SecurityProtocolType)_Tls12;
                ServicePointManager.SecurityProtocol = Tls12;
                try
                {
                    response = (HttpWebResponse)request.GetResponse();
                    X509Certificate cert = request.ServicePoint.Certificate;
                    cert2 = new X509Certificate2(cert);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    if(ex.InnerException != null)
                    {
                        MessageBox.Show("InnerException:" + ex.Message);
                    }
                    else
                    {
                        MessageBox.Show("InnerException is null:" + ex.Message);
                    }
                    strException = ex.Message;
                    if (request.ServicePoint.Certificate != null)
                    {
                        X509Certificate cert = request.ServicePoint.Certificate;
                        cert2 = new X509Certificate2(cert);
                    }
                }
                finally
                {
                    if (response != null)
                    {
                        response.Close();
                    }

                    if (cert2 != null)
                    {
                        string cedate = cert2.GetExpirationDateString();
                        MessageBox.Show(cedate);
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    MessageBox.Show("InnerException:" + ex.Message);
                }
                else
                {
                    MessageBox.Show("InnerException is null:" + ex.Message);
                }
                Logger.LogError(ex);
            }
        }
        private void btnDBcheck_Click(object sender, EventArgs e)
        {
            try
            {
                string s = RSAAlert.AssetWise.StringCipher.Encrypt("MPORDR_YA123", "keyforrsa");

                //string connection_string = @"Data Source=ECLPP;User ID=KAZOO;Max Pool Size=256;password=Eclipse_2012";
                //using (Oracle.DataAccess.Client.OracleConnection conn = new Oracle.DataAccess.Client.OracleConnection(connection_string))
                //{
                //    conn.Open();
                //    MessageBox.Show("Opened");
                //}

                // string s = RSAAlert.AssetWise.StringCipher.Encrypt("User_10_PRO_IPG", "keyforrsa");

                //string connection_string =@"server=gvs12061.austin.hpicorp.net,2048; database=IPG_sales; UID=ipg_sales_user; PWD=User_10_PRO_IPG;Connect Timeout=400; pooling='true'; Max Pool Size=200";
                //using (SqlConnection conn = new SqlConnection(connection_string))
                //{
                //    conn.Open();
                //    MessageBox.Show("Opened");
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Logger.LogError(ex);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //var ping = new Ping();
            //PingReply reply = ping.Send("g1w9147c.austin.hpicorp.net", 15 * 1000);
            //if(reply.Status != IPStatus.Success)
            //{
            //    //send alert.
            //}

            string[] fileEntries = System.IO.Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + "InputFiles", "ServerPingConfig*.*");
            foreach (string strFilePath in fileEntries)
            {
                //Generate Log File events
                var serializer = new XmlSerializer(typeof(ServerPingConfig));
                using (var reader = XmlReader.Create(strFilePath))
                {
                    ServerPingConfig ServerPingConfig = (ServerPingConfig)serializer.Deserialize(reader);

                    foreach (ServerConfig objServerConfig in ServerPingConfig.ServerConfig)
                    {
                        System.Timers.Timer objTimer = new System.Timers.Timer();
                        objTimer.Interval = objServerConfig.IntervalInMinutes * 60000;
                        objTimer.Elapsed += delegate { PingServerAndAlertIfDown(objServerConfig); };
                        objTimer.Enabled = true;
                    }
                }
            }
        }

        private void PingServerAndAlertIfDown(ServerConfig objServerConfig)
        {
            string AlertMessages = string.Empty;

            foreach (string objserverAddress in objServerConfig.ServerAddress.PhysicalAddress)
            {
                var ping = new Ping();
                PingReply reply = ping.Send(objserverAddress, 15 * 1000);
                if (reply.Status != IPStatus.Success)
                {
                    AlertMessages += "System/Server is not accessible " + objserverAddress;
                    AlertMessages += "\r\n";
                }
            }

            //send alert.
            if (string.IsNullOrEmpty(AlertMessages))
            {
                Email objemail = new Email();
                objemail.body = objServerConfig.AlertEMailBody;
                objemail.subject = AlertMessages;
                objemail.to = objServerConfig.AlertEMails;
                objemail.SendEmail();
            }
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            //  textBox2.Text = RSAAlert.AssetWise.StringCipher.Encrypt(textBox1.Text.Trim(), "keyforrsa");
            textBox2.Text = RSAAlert.AssetWise.StringCipher.Encrypt(textBox1.Text.Trim(), "this encryption key is used for the event server 159$$"); 
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            //textBox1.Text = RSAAlert.AssetWise.StringCipher.Decrypt(textBox2.Text.Trim(), "keyforrsa");
             textBox1.Text = RSAAlert.AssetWise.StringCipher.Decrypt(textBox2.Text.Trim(), "this encryption key is used for the event server 159$$");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            List<MemoryUsage> memory_list = new List<MemoryUsage>();

            //2018-01-10 08:09:49,795 [24] INFO  RSAAlert Percentage CPU used(g1w9274.austin.hpicorp.net):    23.75
            string[] fileRecords = Utils.GetFileRecords(AppDomain.CurrentDomain.BaseDirectory + "LogFiles\\ServerStat.log");

            DataTable dt = Data.GetData("g1w9274.austin.hpicorp.net", "CPU");

            DataView view = new DataView(dt);
            DataTable distinctValues = view.ToTable(true, "name");

            foreach (DataRow dr in distinctValues.Rows)
            {
                string name = dr["name"].ToString();
                DataRow[] result = dt.Select("name = '" + name + "'");

                MemoryUsage objMemoryUsage = new MemoryUsage();
                objMemoryUsage.name = name;

                foreach (DataRow row in result)
                {
                    var epoch = (Convert.ToDateTime(row["Datetime"]) - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
                    epoch = epoch * 1000;

                    double PercentUsed = 0;

                    if (("CPU").Equals(name))
                    {
                        PercentUsed = Convert.ToDouble(row["Consumed"]) * 100 / Convert.ToDouble(row["Total"]);
                        PercentUsed = Math.Round(PercentUsed, 2);
                    }
                    else
                    {
                        PercentUsed = Convert.ToDouble(row["Consumed"]);
                    }

                    objMemoryUsage.Memory_UsageInfo.Add(new KeyValuePair<object, double>(epoch, PercentUsed));
                }

                memory_list.Add(objMemoryUsage);
            }

            // //Server#Name#Datetime#Total#Consumed
            //foreach (DataRow dr in dt.Rows)
            //{
            //    var epoch = (Convert.ToDateTime(dr["Datetime"]) - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
            //    epoch = epoch * 1000;
            //    double PercentUsed = Convert.ToDouble(dr["Consumed"]) * 100 / Convert.ToDouble(dr["Total"]);
            //    PercentUsed = Math.Round(PercentUsed, 2);

            //    Memory_UsageInfo.Add(new KeyValuePair<object, double>(epoch, PercentUsed));
            //}
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Email objemail = new Email();
            objemail.body = "test";
            objemail.subject = "test";
            objemail.to = "rupesh.shivarkar1@hp.com";
            objemail.SendEmail();
        }

        public DataTable ConvertToDataTable(string filePath, int numberOfColumns)
        {
            DataTable tbl = new DataTable();
            try
            {
                //Server#Name#Datetime#Total#Consumed
                tbl.Columns.Add("Server", typeof(String));
                tbl.Columns.Add("Name", typeof(String));
                tbl.Columns.Add("Datetime", typeof(DateTime));
                tbl.Columns.Add("Total", typeof(double));
                tbl.Columns.Add("Consumed", typeof(double));

                string[] lines = System.IO.File.ReadAllLines(filePath);

                bool bSkipFirstLine = true;
                foreach (string line in lines)
                {
                    if (bSkipFirstLine)
                    {
                        bSkipFirstLine = false;
                        continue;
                    }
                    var cols = line.Split('#');

                    DataRow row = tbl.NewRow();
                    row.ItemArray = (object[])cols;
                    tbl.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex);
            }

            return tbl;
        }

        public DayOfWeek GetDayOfWeek(String strDayName)
        {
            switch (strDayName.ToLower())
            {
                case "sunday":
                    return DayOfWeek.Sunday;

                case "monday":
                    return DayOfWeek.Monday;

                case "tuesday":
                    return DayOfWeek.Tuesday;

                case "wednesday":
                    return DayOfWeek.Wednesday;

                case "thursday":
                    return DayOfWeek.Thursday;

                case "friday":
                    return DayOfWeek.Friday;

                case "saturday":
                    return DayOfWeek.Saturday;
            }

            return DayOfWeek.Sunday;//default
        }

        public DateTime GetNextWeekDatetimeFromGivenDate(DateTime dt, string strWeekDayAndTime)
        {
            string strNextWeekDay = strWeekDayAndTime.Split(',')[0];
            string strStartTime = strWeekDayAndTime.Split(',')[1];

            DayOfWeek ExceptionStartDay = GetDayOfWeek(strNextWeekDay);

            int addDays = (((int)ExceptionStartDay - (int)dt.DayOfWeek + 7) % 7);
            DateTime dtGetNextWeekDayDateTime = dt.AddDays(addDays);

            int hours = Int32.Parse(strStartTime.Split(':')[0]);
            int minutes = Int32.Parse(strStartTime.Split(':')[1]);
            int seconds = Int32.Parse(strStartTime.Split(':')[2]);
            TimeSpan ts = new TimeSpan(Int32.Parse(strStartTime.Split(':')[0]), Int32.Parse(strStartTime.Split(':')[1]), Int32.Parse(strStartTime.Split(':')[2]));
            dtGetNextWeekDayDateTime = dtGetNextWeekDayDateTime + ts;

            return dtGetNextWeekDayDateTime;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string DoNotRunBetweenThisTimeUTC = "TUESDAY,04:00:00-TUESDAY,16:00:00";

            DateTime now = DateTime.UtcNow;
            now = new DateTime(now.Year, now.Month, now.Day, 0, 0, 0);
            DateTime dtNextExceptionStart = GetNextWeekDatetimeFromGivenDate(now, DoNotRunBetweenThisTimeUTC.Split('-')[0]);
            DateTime dtNextExceptionEnd = GetNextWeekDatetimeFromGivenDate(new DateTime(dtNextExceptionStart.Year, dtNextExceptionStart.Month, dtNextExceptionStart.Day, 0, 0, 0), DoNotRunBetweenThisTimeUTC.Split('-')[1]);

            if (DateTime.UtcNow > dtNextExceptionStart && DateTime.UtcNow < dtNextExceptionEnd)
            {
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                StreamWriter swFileLog = new StreamWriter(@"C:\Rupesh_Data\OneDrive\OneDrive - HP\2018\Pricing colud\PARTNER_PRICING.log", true);
                for (int ii = 0; ii < 1000; ii++)
                {
      
                    Random rnd = new Random();
                    int DEAL_BD_NR = rnd.Next(10000, 50000);
                    int EUC_ORG_ID = rnd.Next(10000, 50000);
                    string CURR_CD = "UD";
                    string SKU = "SKU_" + ii.ToString();
                    double LIST_PRICE = rnd.Next(1000, 90000);
                    double  CUST_NET_PRICE = LIST_PRICE - rnd.Next(100, 900);

                    System.Threading.Thread.Sleep(100);

                    swFileLog.WriteLine(DEAL_BD_NR + "#" + EUC_ORG_ID + "#" + CURR_CD + "#" + SKU + "#" + LIST_PRICE + "#" + CUST_NET_PRICE + "#3/29/2018");
                }
                swFileLog.Close();
            }

            catch (Exception ex)
            {
               
            }
        }
    }
}