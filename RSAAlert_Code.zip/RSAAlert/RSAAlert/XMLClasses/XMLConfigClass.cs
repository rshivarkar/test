﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Serialization;

namespace RSAAlert.XMLClasses
{
    /*Base Classes start */

    //This is base class for config and each class should derive from it.
    public class RSAConfig : AlertEmail
    {
        [XmlElement("IntervalInMinutes")]
        public int IntervalInMinutes { get; set; }

        [XmlElement("UTCStartTimeHour")]
        public int UTCStartTimeHour { get; set; }

        [XmlElement("UTCStartTimeMins")]
        public int UTCStartTimeMins { get; set; }

        [XmlElement("DoNotRunBetweenThisTimeUTC")]
        public string DoNotRunBetweenThisTimeUTC { get; set; }
    }

    public class AlertEmail
    {
        [XmlElement("AlertEMails")]
        public string AlertEMails { get; set; }

        [XmlElement("AlertEMailSubject")]
        public string AlertEMailSubject { get; set; }

        [XmlElement("AlertEMailBody")]
        public string AlertEMailBody { get; set; }
    }

    /*Base classes Ends */

    /*Error log file config Classes start */

    [XmlRoot("LogFileErrorConfigs")]
    public class LogFileErrorConfigs
    {
        [XmlElement("LogFileErrorConfig")]
        public List<LogFileErrorConfig> LogFileErrorConfig { get; set; }
    }

    public class LogFileErrorConfig : AlertEmail
    {
        [XmlElement("AssetName")]
        public string AssetName { get; set; }

        [XmlElement("Environment")]
        public string Environment { get; set; }

        [XmlElement("CustomLogic")]
        public string CustomLogic { get; set; }

        [XmlElement("IntervalInMinutes")]
        public int IntervalInMinutes { get; set; }

        [XmlElement("LogFilePaths")]
        public LogFilePaths LogFilePaths { get; set; }

        [XmlElement("ErrorMessagesToSearch")]
        public ErrorMessagesToSearch ErrorMessagesToSearch { get; set; }

        [XmlElement("LastCheckedLineNumber")]
        public string LastCheckedLineNumber { get; set; }
    }

    [Serializable]
    public class LogFilePaths
    {
        [XmlElement("LogFilePath")]
        public List<string> LogFilePath { get; set; }
    }

    [Serializable]
    public class ErrorMessagesToSearch
    {
        [XmlElement("ErrorMessageToSearch")]
        public List<string> ErrorMessageToSearch { get; set; }
    }

    /*SSL config Classes start */

    [XmlRoot("SSLConfigs")]
    public class SSLConfigs : RSAConfig
    {
        [XmlElement("CustomLogic")]
        public string CustomLogic { get; set; }

        [XmlElement("SSLConfig")]
        public List<SSLConfig> SSLConfig { get; set; }
    }

    public class SSLConfig
    {
        [XmlElement("AssetName")]
        public string AssetName { get; set; }

        [XmlElement("Environment")]
        public string Environment { get; set; }

        [XmlElement("URLS")]
        public URLS URLS { get; set; }
    }

    public class URLS
    {
        [XmlElement("URL")]
        public List<string> URL { get; set; }
    }

    /*DB config Classes start */

    [XmlRoot("DBConfigs")]
    public class DBConfigs
    {
        [XmlElement("DBConfig")]
        public List<DBConfig> DBConfig { get; set; }
    }

    public class DBConfig : RSAConfig
    {
        [XmlElement("AssetName")]
        public string AssetName { get; set; }

        [XmlElement("Environment")]
        public string Environment { get; set; }

        [XmlElement("ServerType")]
        public string ServerType { get; set; }

        [XmlElement("DBUser")]
        public string DBUser { get; set; }

        [XmlElement("DBPassword")]
        public string DBPassword { get; set; }

        [XmlElement("SQLDatabase")]
        public string SQLDatabase { get; set; }

        [XmlElement("ConnecionString")]
        public string ConnecionString { get; set; }

        [XmlElement("Queries")]
        public Queries Queries { get; set; }
    }

    public class Queries
    {
        [XmlElement("Query")]
        public List<Query> Query { get; set; }
    }

    public class Query : AlertEmail
    {
        [XmlElement("QueryName")]
        public string QueryName { get; set; }

        [XmlElement("QueryText")]
        public string QueryText { get; set; }

        [XmlElement("CustomLogic")]
        public string CustomLogic { get; set; }

        [XmlElement("IntervalInMinutes")]
        public int IntervalInMinutes { get; set; }

        [XmlElement("AlertCondition")]
        public string AlertCondition { get; set; }
    }

    [XmlRoot("ServerPingConfig")]
    public class ServerPingConfig
    {
        [XmlElement("ServerConfig")]
        public List<ServerConfig> ServerConfig { get; set; }
    }

    public class ServerConfig : AlertEmail
    {
        [XmlElement("AssetName")]
        public string AssetName { get; set; }

        [XmlElement("Environment")]
        public string Environment { get; set; }

        [XmlElement("CustomLogic")]
        public string CustomLogic { get; set; }

        [XmlElement("IntervalInMinutes")]
        public int IntervalInMinutes { get; set; }

        [XmlElement("ServerAddress")]
        public ServerAddress ServerAddress { get; set; }
    }

    public class ServerAddress
    {
        [XmlElement("PhysicalAddress")]
        public List<string> PhysicalAddress { get; set; }
    }

    [XmlRoot("ServerStatConfigs")]
    public class ServerStatConfigs
    {
        [XmlElement("ServerStatConfig")]
        public List<ServerStatConfig> ServerStatConfig { get; set; }
    }

    public class ServerStatConfig : RSAConfig
    {
        [XmlElement("AssetName")]
        public string AssetName { get; set; }

        [XmlElement("Environment")]
        public string Environment { get; set; }

        [XmlElement("ServerType")]
        public string ServerType { get; set; }

        [XmlElement("User")]
        public string User { get; set; }

        [XmlElement("Password")]
        public string Password { get; set; }

        [XmlElement("PhysicalAddress")]
        public string PhysicalAddress { get; set; }

        [XmlElement("CPUAlertCondition")]
        public string CPUAlertCondition { get; set; }

        [XmlElement("DiskAlertCondition")]
        public string DiskAlertCondition { get; set; }

        [XmlElement("Processes")]
        public Processes Processes { get; set; }
    }

    public class Processes
    {
        [XmlElement("Process")]
        public List<Process> Process { get; set; }
    }

    public class Process
    {
        [XmlElement("ProcessName")]
        public string ProcessName { get; set; }

        [XmlElement("AlertCondition")]
        public string AlertCondition { get; set; }

        [XmlElement("DoNotRunBetweenThisTimeUTC")]
        public string DoNotRunBetweenThisTimeUTC { get; set; }
    }

    [XmlRoot("QuoteConfigs")]
    public class QuoteConfigs
    {
        [XmlElement("QuoteConfig")]
        public List<QuoteConfig> QuoteConfig { get; set; }
    }

    public class QuoteConfig : RSAConfig
    {
        [XmlElement("AssetName")]
        public string AssetName { get; set; }

        [XmlElement("Environment")]
        public string Environment { get; set; }

        [XmlElement("QuoteGenerateThresholdSeconds")]
        public int QuoteGenerateThresholdSeconds { get; set; }

        [XmlElement("QuoteFileMinSizeBytes")]
        public int QuoteFileMinSizeBytes { get; set; }

        [XmlElement("QuoteSites")]
        public string QuoteSites { get; set; }
    }
}