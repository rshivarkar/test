﻿using RSAAlert.Common;
using System;
using System.IO;

namespace RSAAlert
{
    internal static class Utils
    {
        private static readonly string CLASSNAME = System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name + ".";

        public static string[] GetFileRecords(string logFilePath)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";

            string[] fileRecords = null;
            try
            {
                if (System.IO.File.Exists(logFilePath))
                {
                    Stream stream = File.Open(logFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    StreamReader reader = new StreamReader(stream);

                    string LogData = reader.ReadToEnd();
                    reader.Close();
                    reader.Dispose();
                    reader = null;

                    string[] delimiter = new string[1] { '\t'.ToString() };
                    delimiter[0] = System.Environment.NewLine;

                    fileRecords = LogData.Split(delimiter, StringSplitOptions.RemoveEmptyEntries);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME + ex);
            }
            return fileRecords;
        }
    }
}