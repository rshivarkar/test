﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RSAAlert.Common;
using RSAAlert.XMLClasses;
using System.Reflection;
namespace RSAAlert.Common
{
    public class DiskSpace
    {
        public string caption { get; set; }
        public double freespace_GB { get; set; }
        public double size_GB { get; set; }
        public double PerCentUsed { get; set; }
    }

    public class ProcessStat
    {
        public string name { get; set; }

        public string alertCondition { get; set; }

        public bool IsRunning { get; set; }

        public double Memoru_size_MB { get; set; }

        public ProcessStat()
        {
            name = "";
            IsRunning = false;
            Memoru_size_MB = 0;
        }
    }
    public class SystemCheck
    {
        private static readonly string CLASSNAME = System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name + ".";

        public string computerName { get; set; }
        public string userid { get; set; }
        public string password { get; set; }

        public double TotalVisibleMemorySize_GB { get; set; }
        public double FreePhysicalMemory_GB { get; set; }
        public double UsedPhysicalMemory_GB { get; set; }
        public double PerCentUsedMemory { get; set; }

        public List<DiskSpace> lstDiskSpace = new List<DiskSpace>();

        public List<ProcessStat> lstProcessStat = new List<ProcessStat>();

        public SystemCheck()
        {
            computerName = ""; userid = ""; password = "";
            TotalVisibleMemorySize_GB = FreePhysicalMemory_GB = UsedPhysicalMemory_GB = PerCentUsedMemory = 0;
        }

        public bool GetRAMStats()
        {
            bool bGetRAmStats = false;

            try
            {
                System.Management.ConnectionOptions options = new System.Management.ConnectionOptions();
                options.Authentication = System.Management.AuthenticationLevel.PacketPrivacy;

                if (!string.IsNullOrEmpty(userid))
                {
                    options.Username = userid;
                    options.Password = password;
                }

                System.Management.ManagementScope ms = new System.Management.ManagementScope(@"\\" + computerName + @"\root\cimv2", options);
                System.Management.SelectQuery sq = new System.Management.SelectQuery("SELECT * FROM Win32_OperatingSystem");
                System.Management.ManagementObjectSearcher mos = new System.Management.ManagementObjectSearcher(ms, sq);

                using (System.Management.ManagementObjectSearcher searcher = new
               System.Management.ManagementObjectSearcher(ms, sq))
                {

                    System.Management.ManagementObjectCollection collection = searcher.Get();
                    foreach (System.Management.ManagementObject mo in collection)
                    {

                        if (mo.Properties["TotalVisibleMemorySize"] != null && mo.Properties["FreePhysicalMemory"] != null)
                        {
                            TotalVisibleMemorySize_GB = Convert.ToDouble(mo.Properties["TotalVisibleMemorySize"].Value) / 1048576;
                            FreePhysicalMemory_GB = Convert.ToDouble(mo.Properties["FreePhysicalMemory"].Value) / 1048576;
                        }
                    }
                }


                if (TotalVisibleMemorySize_GB > 0)
                {
                    UsedPhysicalMemory_GB = TotalVisibleMemorySize_GB - FreePhysicalMemory_GB;
                    PerCentUsedMemory = 100 * UsedPhysicalMemory_GB / TotalVisibleMemorySize_GB;
                }

                bGetRAmStats = true;
            }
            catch (Exception ex)
            {
                Logger.LogError("GetRAMStats=> " + ex);
                bGetRAmStats = false;
                return bGetRAmStats;
            }

            return bGetRAmStats;
        }

        public bool GetDiskstats()
        {
            bool bGetDiskStat = false;

            try
            {
                System.Management.ConnectionOptions options = new System.Management.ConnectionOptions();
                options.Authentication = System.Management.AuthenticationLevel.PacketPrivacy;

                if (!string.IsNullOrEmpty(userid))
                {
                    options.Username = userid;
                    options.Password = password;
                }

                System.Management.ManagementScope ms = new System.Management.ManagementScope(@"\\" + computerName + @"\root\cimv2", options);
                System.Management.SelectQuery sq = new System.Management.SelectQuery("SELECT * FROM CIM_LogicalDisk");

                System.Management.ManagementObjectSearcher mos = new System.Management.ManagementObjectSearcher(ms, sq);



                using (System.Management.ManagementObjectSearcher searcher = new
     System.Management.ManagementObjectSearcher(ms, sq))
                {

                    System.Management.ManagementObjectCollection collection = searcher.Get();
                    foreach (System.Management.ManagementObject mo in collection)
                    {
                        if (mo.Properties["Caption"] != null && mo.Properties["FreeSpace"] != null && mo.Properties["Size"] != null)
                        {
                            DiskSpace objdiskapce = new DiskSpace();
                            objdiskapce.caption = mo.Properties["Caption"].Value.ToString();
                            objdiskapce.freespace_GB = Convert.ToDouble(mo.Properties["FreeSpace"].Value) / 1073741824;
                            objdiskapce.size_GB = Convert.ToDouble(mo.Properties["Size"].Value) / 1073741824;

                            objdiskapce.PerCentUsed = 100 * (objdiskapce.size_GB - objdiskapce.freespace_GB) / objdiskapce.size_GB;
                            lstDiskSpace.Add(objdiskapce);
                        }
                    }
                }

                bGetDiskStat = true;
            }
            catch (Exception ex)
            {
                 Logger.LogError("GetRAMStats=> " + ex);
                bGetDiskStat = false;
                return bGetDiskStat;
            }
            return bGetDiskStat;
        }

        public bool GetProcessStats()
        {
            bool bGetProcessStats = false;

            try
            {
                System.Management.ConnectionOptions options = new System.Management.ConnectionOptions();
                options.Authentication = System.Management.AuthenticationLevel.PacketPrivacy;

                if (!string.IsNullOrEmpty(userid))
                {
                    options.Username = userid;
                    options.Password = password;
                }

                string ProcessNamesWhereCond = "";

                foreach (ProcessStat objprocessStat in lstProcessStat)
                {
                    if (!string.IsNullOrEmpty(ProcessNamesWhereCond))
                        ProcessNamesWhereCond = ProcessNamesWhereCond + " OR ";
                    ProcessNamesWhereCond += "name='" + objprocessStat.name + "'";
                }

                string strQuery = "SELECT * FROM Win32_Process where ( " + ProcessNamesWhereCond + " )";

                System.Management.ManagementScope ms = new System.Management.ManagementScope(@"\\" + computerName + @"\root\cimv2", options);
                System.Management.SelectQuery sq = new System.Management.SelectQuery(strQuery);

                using (System.Management.ManagementObjectSearcher searcher = new
                           System.Management.ManagementObjectSearcher(ms, sq))
                {

                    System.Management.ManagementObjectCollection collection = searcher.Get();
                    foreach (System.Management.ManagementObject mo in collection)
                    {
                        foreach (ProcessStat objprocessStat in lstProcessStat)
                        {
                            if (mo.Properties["Name"] != null && mo.Properties["Name"].Value.Equals(objprocessStat.name))
                            {
                                objprocessStat.IsRunning = true;
                                objprocessStat.Memoru_size_MB = Convert.ToDouble(mo.Properties["WorkingSetSize"].Value.ToString()) * 0.000001;
                            }
                        }
                    }
                }

                bGetProcessStats = true;
            }
            catch (Exception ex)
            {
                 Logger.LogError(ex);
                return false;
            }

            return bGetProcessStats;
        }


    }
}
