﻿using RSAAlert.XMLClasses;
using System;
using System.IO;
using System.Timers;
using System.Xml;
using System.Xml.Serialization;

namespace RSAAlert.Common
{
    internal class ScheduleJob
    {
        private int hours;
        private int minutes;
        private int intervalInMinutes;
        private string Action;
        private bool IsJobRunning;
        public object objectInfo;

        private static readonly string CLASSNAME =
    System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name + ".";

        public ScheduleJob(int hours, int minutes, int intervalInMinutes, string Action)
        {
            this.IsJobRunning = false;
            this.hours = hours;
            this.minutes = minutes;
            this.Action = Action;
            this.intervalInMinutes = intervalInMinutes;//default 24 hours
        }

        public void StartJob()
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";

            try
            {
                DateTime utcnow = DateTime.UtcNow;
                DateTime utcScheduleTime = new DateTime(utcnow.Year, utcnow.Month, utcnow.Day, hours, minutes, 0);
                bool bstartNow = false;
                if (hours == -1 && minutes == -1)
                    bstartNow = true;
                JobActionMain(JobActionThread, utcScheduleTime, bstartNow);
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
        }

        private async void JobActionMain(Action action, DateTime ExecutionTime, bool bStartNow)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";

            try
            {
                double waittime = (int)ExecutionTime.Subtract(DateTime.UtcNow).TotalMilliseconds;
                //if time is minus means schedule time is passed for this day so need to schedule for next day
                if( waittime < 0)
                {
                    waittime = waittime + (24 * 60 * 60 * 1000);//for one day miliseconds  - 24 * 60 * 60 * 1000
                }

                await System.Threading.Tasks.Task.Delay((int)waittime);
                action();
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
        }

        private void JobActionThread()
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";

            try
            {
                JobActionDelegate();//run now

                //Schedule now
                Timer objTimer = new Timer();
                objTimer.Interval = intervalInMinutes * 60000;
                objTimer.Elapsed += delegate { JobActionDelegate(); };
                objTimer.Enabled = true;
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
        }

        private void JobActionDelegate()
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";

            if (this.IsJobRunning)
            {
                Logger.LogInfo(FUNC_NAME + " Job is already running " + this.Action );
                return;
            }
            try
            {
                if (Action.Equals("SSLCheck"))
                {
                    var serializerSSL = new XmlSerializer(typeof(SSLConfigs));
                  
                    using (var reader = XmlReader.Create(AppDomain.CurrentDomain.BaseDirectory + "InputFiles\\SSLConfig.xml"))
                    {
                        this.IsJobRunning = true;
                        SSLConfigs objSSLConfigs = (SSLConfigs)serializerSSL.Deserialize(reader);
                        RSAAlert.AssetWise.Common.CheckSSLAndAlert(objSSLConfigs);
                       
                    }
                }
                else if (Action.Contains("DBCheck"))
                {
                    this.IsJobRunning = true;
                    DBConfig objDbConfig = (DBConfig)this.objectInfo;
                    RSAAlert.AssetWise.DB objDB = new AssetWise.DB(objDbConfig.ConnecionString, objDbConfig.DBUser, objDbConfig.DBPassword, "", objDbConfig.ServerType);
                    objDB.RunDBQueries(objDbConfig);
                }

                this.IsJobRunning = false;
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
        }
    }
}