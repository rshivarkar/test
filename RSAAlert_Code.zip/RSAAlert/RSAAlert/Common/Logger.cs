﻿using System;
using System.Net;
using System.Threading;

using log4net;

//[assembly: log4net.Config.XmlConfigurator(Watch = true)]

namespace RSAAlert.Common
{
   
    public sealed class Logger
    {
        /// <summary>
        /// Constant used in LogDebugArgument()
        /// </summary>
        private const string FMT_DEBUG_ARGUMENT = "{0}{1} = \"{2}\"";
        private const string BEGIN = "begin";
        private const string HP = "RSAAlert";
        private const string USERID = "userId";
        private const string SYSTEM = "system";
        private const string MACHINENM = "machineNm";

        /// <summary>
        /// logger used to log all level of messages. This defines a root logger of HP,
        /// which all logged messages should descend from. Controlling of logging 
        /// occurrs in the App.Config file at the consumer level.
        /// </summary>
        private static ILog _log = log4net.LogManager.GetLogger(
            System.Reflection.Assembly.GetCallingAssembly(), HP);

        /// <summary>
        /// Used for each log call
        /// </summary>
        private static readonly string _hostName = Dns.GetHostName();

        /// <summary>
        /// Global data used for logger
        /// </summary>
        public static readonly bool isDebugEnabled = _log.IsDebugEnabled;
        public static readonly bool isInfoEnabled = _log.IsInfoEnabled;
        public static readonly bool isErrorEnabled = _log.IsErrorEnabled;
        public static readonly bool isFatalEnabled = _log.IsFatalEnabled;
        public static readonly bool isWarnEnabled = _log.IsWarnEnabled;

        /// <summary>
        /// Logs an argument in Debug. Useful if the argument is null as it outputs
        /// the null state else it calls ToString() on the object
        /// Example: NebulaDealBusLogicManager.UnLockDeal(): bdId = "9112689"
        /// </summary>
        /// <param name="functionString">calling function string</param>
        /// <param name="argumentName">The name of the argument to log</param>
        /// <param name="argumentValue">argument value to log</param>
        public static void LogDebugArgument(string functionString, string argumentName, object argumentValue)
        {
            LogDebug(String.Format(FMT_DEBUG_ARGUMENT, functionString,
                argumentName, (argumentValue == null ? "null" : argumentValue.ToString())), null);
        }

        /// <summary>
        /// Logs an argument in Info. Useful if the argument is null as it outputs
        /// the null state else it calls ToString() on the object
        /// Example: NebulaDealBusLogicManager.UnLockDeal(): bdId = "9112689"
        /// </summary>
        /// <param name="functionString">calling function string</param>
        /// <param name="argumentName">The name of the argument to log</param>
        /// <param name="argumentValue">argument value to log</param>
        public static void LogInfoArgument(string functionString, string argumentName, object argumentValue)
        {
            LogInfo(String.Format(FMT_DEBUG_ARGUMENT, functionString,
                argumentName, (argumentValue == null ? "null" : argumentValue.ToString())), null);
        }

        /// <summary>
        /// Logs an argument in Error. Useful if the argument is null as it outputs
        /// the null state else it calls ToString() on the object
        /// Example: NebulaDealBusLogicManager.UnLockDeal(): bdId = "9112689"
        /// </summary>
        /// <param name="functionString">calling function string</param>
        /// <param name="argumentName">The name of the argument to log</param>
        /// <param name="argumentValue">argument value to log</param>
        public static void LogErrorArgument(string functionString, string argumentName, object argumentValue)
        {
            LogError(String.Format(FMT_DEBUG_ARGUMENT, functionString,
                argumentName, (argumentValue == null ? "null" : argumentValue.ToString())), null);
        }

        /// <summary>
        /// Logs the function string as beginning.
        /// Example: CounterServerSink.ProcessMessage(): begin
        /// </summary>
        /// <param name="functionString">calling function string</param>
        public static void LogDebugBegin(string functionString)
        {
            LogDebug(String.Concat(functionString, BEGIN), null);
        }

        /// <summary>
        /// Used to Log a Debug level message
        /// </summary>
        /// <param name="message">message to log</param>
        public static void LogDebug(object message)
        {
            LogDebug(message, null);
        }

        /// <summary>
        /// Used to Log a Debug level message
        /// </summary>
        /// <param name="message">message to log</param>
        /// <param name="ex">exception to log</param>
        public static void LogDebug(object message, Exception ex)
        {
            SetMDCDefaults();
            _log.Debug(message, ex);
        }

        /// <summary>
        /// Used to Log a Info level message
        /// </summary>
        /// <param name="message">message to log</param>
        public static void LogInfo(object message)
        {
            LogInfo(message, null);
        }

        /// <summary>
        /// Used to Log a Info level message
        /// </summary>
        /// <param name="message">message to log</param>
        /// <param name="ex">exception to log</param>
        public static void LogInfo(object message, Exception ex)
        {
            SetMDCDefaults();
            _log.Info(message, ex);
        }

        /// <summary>
        /// Used to Log a Warn level message
        /// </summary>
        /// <param name="message">message to log</param>
        public static void LogWarn(object message)
        {
            LogWarn(message, null);
        }

        /// <summary>
        /// Used to Log a Warn level message
        /// </summary>
        /// <param name="message">message to log</param>
        /// <param name="ex">exception to log</param>
        public static void LogWarn(object message, Exception ex)
        {
            SetMDCDefaults();
            _log.Warn(message, ex);
        }

        /// <summary>
        /// Used to Log a Error level message
        /// </summary>
        /// <param name="message">message to log</param>
        public static void LogError(object message)
        {
            LogError(message, null);
        }

        /// <summary>
        /// Used to Log a Error level message
        /// </summary>
        /// <param name="message">message to log</param>
        /// <param name="ex">exception to log</param>
        public static void LogError(object message, Exception ex)
        {
            SetMDCDefaults();
            _log.Error(message, ex);
        }

        /// <summary>
        /// Logs as Fatal adding the machine name to the log message.
        /// </summary>
        /// <param name="ex">exception to log</param>
        public static void LogFatal(object message)
        {
            LogFatal(message, null);
        }

        /// <summary>
        /// Logs as Fatal adding the machine name to the log message.
        /// </summary>
        /// <param name="message">Message to log</param>
        /// <param name="ex">exception to log</param>
        public static void LogFatal(object message, Exception ex)
        {
            SetMDCDefaults();
            _log.Fatal(message, ex);
        }

        /// <summary>
        /// Set's the UserID to associated with logging. Requires the Log4Net settings
        /// to consume "%X(userId)"
        /// </summary>
        /// <param name="userId">userId to log</param>
        public static void SetUserID(string userId)
        {
            MDC.Set(USERID, userId);
        }

        //******************** PRIVATE METHODS ********************/

        /// <summary>
        /// Adds the default Log4Net MDC values for "%X(machineNm)" and "%X(userId)".
        /// </summary>
        private static void SetMDCDefaults()
        {
            try
            {
                // Always set the machine name
                MDC.Set(MACHINENM, _hostName);

                if (MDC.Get(USERID) == null)
                    MDC.Set(USERID, SYSTEM);
            }
            catch (Exception)
            {
                // do nothing as the MDC will have been freed out
            }
        }
    }
}
