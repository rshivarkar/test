﻿using RSAAlert.Common;
using RSAAlert.XMLClasses;
using System;
using System.Net.Http;
using System.ServiceProcess;
using System.Threading.Tasks;
using System.Timers;
using System.Web.Http;
using System.Web.Http.SelfHost;
using System.Xml;
using System.Xml.Serialization;

namespace RSAAlert
{
    public partial class RSAAlertService : ServiceBase
    {
        private static readonly string CLASSNAME =
   System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name + ".";

        public RSAAlertService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo("Service Started...");

            try
            {
                //Log File Thread
                Logger.LogInfo("starting LogFileErrorConfig thread");
                System.Threading.Thread LogFileThread = new System.Threading.Thread(new System.Threading.ThreadStart(LogFileCheckThread));
                LogFileThread.Start();
                Logger.LogInfo("Completed LogFileErrorConfig thread..");

                //Generate SSL events
                Logger.LogInfo("starting SSLConfig thread");
                System.Threading.Thread SSLThread = new System.Threading.Thread(new System.Threading.ThreadStart(SSLCheckThread));
                SSLThread.Start();
                Logger.LogInfo("Completed SSLConfig thread..");

                ////Generate Database query check events
                Logger.LogInfo("starting DBCheck thread");
                System.Threading.Thread DBThread = new System.Threading.Thread(new System.Threading.ThreadStart(DBCheckThread));
                DBThread.Start();
                Logger.LogInfo("Completed DBCheck thread..");
                //Generate server check ping event
                Logger.LogInfo("starting ServerPingThread thread");
                System.Threading.Thread ServerPingThread = new System.Threading.Thread(new System.Threading.ThreadStart(ServerCheckPingThread));
                ServerPingThread.Start();
                Logger.LogInfo("Completed ServerPingThread thread..");

                //Generate Server stat event
                Logger.LogInfo("starting ServerStatThread thread");
                System.Threading.Thread ServerStatThread = new System.Threading.Thread(new System.Threading.ThreadStart(ServerCheckStatThread));
                ServerStatThread.Start();
                Logger.LogInfo("Completed ServerStatThread thread..");

                //Quote Check thread
                Logger.LogInfo("starting Quote Server check thread");
                System.Threading.Thread QuoteServerThread = new System.Threading.Thread(new System.Threading.ThreadStart(QuoteServerCheckThread));
                QuoteServerThread.Start();
                Logger.LogInfo("Completed Quote Server check..");

                Logger.LogInfo("starting Web API");
                StartWebAPI();
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
        }

        private void StartWebAPI()
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo("Started:" + FUNC_NAME);

            try
            {
                // var config = new HttpSelfHostConfiguration("http://localhost:5555");
                //config.MessageHandlers.Add(new CustomHeaderHandler());

                var config = new HttpSelfHostConfiguration("http://localhost:8080");

                config.MessageHandlers.Add(new CustomHeaderHandler());

                config.Routes.MapHttpRoute(
                    name: "API",
                    routeTemplate: "{controller}/{action}/{id}",
                    defaults: new { id = RouteParameter.Optional }
                    );

                HttpSelfHostServer server = new HttpSelfHostServer(config);
                server.OpenAsync().Wait();

                Logger.LogInfo("Completed:" + FUNC_NAME);
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
        }

        private void ServerCheckPingThread()
        {
            string[] fileEntries = System.IO.Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + "InputFiles", "ServerPingConfig*.*");
            foreach (string strFilePath in fileEntries)
            {
                //Generate Log File events
                var serializer = new XmlSerializer(typeof(ServerPingConfig));
                using (var reader = XmlReader.Create(strFilePath))
                {
                    ServerPingConfig ServerPingConfig = (ServerPingConfig)serializer.Deserialize(reader);

                    foreach (ServerConfig objServerConfig in ServerPingConfig.ServerConfig)
                    {
                        System.Timers.Timer objTimer = new System.Timers.Timer();
                        objTimer.Interval = objServerConfig.IntervalInMinutes * 60000;
                        objTimer.Elapsed += delegate { RSAAlert.AssetWise.Common.PingServerAndAlertIfDown(objServerConfig); };
                        objTimer.Enabled = true;
                    }
                }
            }
        }

        private void LogFileCheckThread()
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo("Started" + FUNC_NAME);

            try
            {
                string[] fileEntries = System.IO.Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + "InputFiles", "LogFileErrorConfig*.*");
                foreach (string strFilePath in fileEntries)
                {
                    //Generate Log File events
                    var serializer = new XmlSerializer(typeof(LogFileErrorConfigs));
                    LogFileErrorConfigs LogFileErrorConfigs = new LogFileErrorConfigs();
                    var reader = XmlReader.Create(strFilePath);
                    LogFileErrorConfigs = (LogFileErrorConfigs)serializer.Deserialize(reader);
                    reader.Close();

                    foreach (LogFileErrorConfig objLogFileErrorConfig in LogFileErrorConfigs.LogFileErrorConfig)
                    {
                        Timer objTimer = new Timer();
                        objTimer.Interval = objLogFileErrorConfig.IntervalInMinutes * 60000;
                        objTimer.Elapsed += delegate
                        {
                            LogFileCheckDelegate(objLogFileErrorConfig);

                            //for generic log check update the last line checked here.
                            if (string.IsNullOrEmpty(objLogFileErrorConfig.CustomLogic))
                            {
                                using (var wfile = new System.IO.StreamWriter(strFilePath))
                                {
                                    System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(typeof(LogFileErrorConfigs));
                                    writer.Serialize(wfile, LogFileErrorConfigs);
                                }
                            }
                        };
                        objTimer.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }

            Logger.LogInfo("Completed" + FUNC_NAME);
        }

        private void SSLCheckThread()
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo("Started:" + FUNC_NAME);

            try
            {
                string[] fileEntries = System.IO.Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + "InputFiles", "SSLConfig*.*");
                foreach (string strFilePath in fileEntries)
                {
                    var serializerSSL = new XmlSerializer(typeof(SSLConfigs));
                    using (var reader = XmlReader.Create(strFilePath))
                    {
                        SSLConfigs objSSLConfigs = (SSLConfigs)serializerSSL.Deserialize(reader);

                        // RSAAlert.AssetWise.Common.CheckSSLAndAlert(objSSLConfigs);

                        ScheduleJob objScheduleJobSSL = new ScheduleJob(objSSLConfigs.UTCStartTimeHour, objSSLConfigs.UTCStartTimeMins, objSSLConfigs.IntervalInMinutes, "SSLCheck");
                        objScheduleJobSSL.StartJob();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }

            Logger.LogInfo("Completed:" + FUNC_NAME);
        }

        private void DBCheckThread()
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo("Started:" + FUNC_NAME);
            try
            {
                string[] fileEntries = System.IO.Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + "InputFiles", "DBConfig*.*");
                foreach (string DBConfigFilePath in fileEntries)
                {
                    var serializerSSL = new XmlSerializer(typeof(DBConfigs));
                    using (var reader = XmlReader.Create(DBConfigFilePath))
                    {
                        DBConfigs objDBConfigs = (DBConfigs)serializerSSL.Deserialize(reader);

                        foreach (DBConfig objDbConfig in objDBConfigs.DBConfig)
                        {
                            if (objDbConfig.IntervalInMinutes == -1 && objDbConfig.UTCStartTimeHour == -1)
                            {
                                RSAAlert.AssetWise.DB objDB = new AssetWise.DB(objDbConfig.ConnecionString, objDbConfig.DBUser, objDbConfig.DBPassword, "", objDbConfig.ServerType);

                                foreach (Query objQuery in objDbConfig.Queries.Query)
                                {
                                    System.Timers.Timer objTimer = new System.Timers.Timer();
                                    objTimer.Interval = objQuery.IntervalInMinutes * 60000;
                                    objTimer.Elapsed += delegate { objDB.RunDBQueriesAndAlert(objQuery); };
                                    objTimer.Enabled = true;
                                }
                            }
                            else
                            {
                                //Schedule to run all at same time.
                                ScheduleJob objScheduleJobSSL = new ScheduleJob(objDbConfig.UTCStartTimeHour, objDbConfig.UTCStartTimeMins, objDbConfig.IntervalInMinutes, "DBCheck");
                                objScheduleJobSSL.objectInfo = objDbConfig;
                                objScheduleJobSSL.StartJob();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
            Logger.LogInfo("Completed:" + FUNC_NAME);
        }

        public void LogFileCheckDelegate(LogFileErrorConfig objLogFileErrorConfig)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";

            try
            {
                if (string.IsNullOrEmpty(objLogFileErrorConfig.CustomLogic))
                {
                    RSAAlert.AssetWise.Common.CheckLogFilesForSpecificErrorsFromLastCheckedLine(objLogFileErrorConfig);
                }
                else
                {
                    if (objLogFileErrorConfig.CustomLogic.Equals("DART-IPC"))
                    {
                        RSAAlert.AssetWise.DART_IPC.CheckLogFiles(objLogFileErrorConfig);
                    }
                    else if (objLogFileErrorConfig.CustomLogic.Equals("CheckLogFileLastModifiedFile"))
                    {
                        RSAAlert.AssetWise.Eclipse.CheckLogFileLastModifiedFile(objLogFileErrorConfig);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
            finally
            {
            }
        }

        private void ServerCheckStatThread()
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo("Started:" + FUNC_NAME);
            try
            {
                string[] fileEntries = System.IO.Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + "InputFiles", "ServerStatConfigs*.*");
                foreach (string DBConfigFilePath in fileEntries)
                {
                    var serializerSSL = new XmlSerializer(typeof(ServerStatConfigs));
                    using (var reader = XmlReader.Create(DBConfigFilePath))
                    {
                        ServerStatConfigs objServerStatConfigs = (ServerStatConfigs)serializerSSL.Deserialize(reader);

                        foreach (ServerStatConfig objServerStatConfig in objServerStatConfigs.ServerStatConfig)
                        {
                            if (objServerStatConfig.UTCStartTimeMins == -1 && objServerStatConfig.UTCStartTimeHour == -1)
                            {
                                System.Threading.Thread.Sleep(60000 * 2);//sleep for 2 minutes before we start another thread here.

                                System.Timers.Timer objTimer = new System.Timers.Timer();
                                objTimer.Interval = objServerStatConfig.IntervalInMinutes * 60000;
                                objTimer.Elapsed += delegate { RSAAlert.AssetWise.Common.CheckServerStatQueryAndAlert(objServerStatConfig); };
                                objTimer.Enabled = true;
                            }
                            else
                            {
                                ////Schedule to run all at same time.
                                //ScheduleJob objScheduleJobSSL = new ScheduleJob(objDbConfig.UTCStartTimeHour, objDbConfig.UTCStartTimeMins, objDbConfig.IntervalInMinutes, "DBCheck");
                                //objScheduleJobSSL.objectInfo = objDbConfig;
                                //objScheduleJobSSL.StartJob();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
            Logger.LogInfo("Completed:" + FUNC_NAME);
        }

        private void QuoteServerCheckThread()
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo("Started:" + FUNC_NAME);
            try
            {
                string[] fileEntries = System.IO.Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + "InputFiles", "QuoteConfig_Eclipse_Alert*.*");
                foreach (string DBConfigFilePath in fileEntries)
                {
                    var serializerSSL = new XmlSerializer(typeof(QuoteConfigs));
                    using (var reader = XmlReader.Create(DBConfigFilePath))
                    {
                        QuoteConfigs objQuoteConfigs = (QuoteConfigs)serializerSSL.Deserialize(reader);

                        foreach (QuoteConfig objQuoteConfig in objQuoteConfigs.QuoteConfig)
                        {
                            if (objQuoteConfig.UTCStartTimeMins == -1 && objQuoteConfig.UTCStartTimeHour == -1)
                            {
                                System.Threading.Thread.Sleep(60000 * 2);//sleep for 2 minutes before we start another thread here.

                                System.Timers.Timer objTimer = new System.Timers.Timer();
                                objTimer.Interval = objQuoteConfig.IntervalInMinutes * 60000;
                                objTimer.Elapsed += delegate { RSAAlert.AssetWise.Eclipse.CheckQuoteServerStatus(objQuoteConfig); };
                                objTimer.Enabled = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }
            Logger.LogInfo("Completed:" + FUNC_NAME);
        }

        protected override void OnStop()
        {
            Logger.LogInfo("Service Stopped...");
        }
    }

    public class CustomHeaderHandler : DelegatingHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, System.Threading.CancellationToken cancellationToken)
        {
            return base.SendAsync(request, cancellationToken)
                .ContinueWith((task) =>
                {
                    HttpResponseMessage response = task.Result;
                    response.Headers.Add("Access-Control-Allow-Origin", "*");
                    response.Headers.Add("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
                    response.Headers.Add("Access-Control-Allow-Headers", "Content-Type, Accept");
                    response.Headers.Add("Access-Control-Max-Age", "1728000");
                    return response;
                });
        }
    }
}