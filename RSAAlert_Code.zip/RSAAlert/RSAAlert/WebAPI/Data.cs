﻿using RSAAlert.Common;
using System;
using System.Data;

namespace RSAAlert.WebAPI
{
    public class Data
    {
        private static readonly string CLASSNAME = System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name + ".";

        public static DataTable GetData(string server, string name)
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo("Started:" + FUNC_NAME);

            DataTable tbl = new DataTable();
            try
            {
                //Server#Name#Datetime#Total#Consumed
                tbl.Columns.Add("Server", typeof(String));
                tbl.Columns.Add("Name", typeof(String));
                tbl.Columns.Add("Datetime", typeof(DateTime));
                tbl.Columns.Add("Total", typeof(double));
                tbl.Columns.Add("Consumed", typeof(double));

                string[] lines = Utils.GetFileRecords(AppDomain.CurrentDomain.BaseDirectory + "LogFiles\\ServerStat.log");

                bool bSkipFirstLine = true;
                foreach (string line in lines)
                {
                    if (bSkipFirstLine)
                    {
                        bSkipFirstLine = false;
                        continue;
                    }

                     if (!line.Contains(server))
                     {
                         continue;
                     }
                    if (!line.Contains(server) || !line.Contains(name))
                    {
                        if (!("CPU").Equals(line) && !line.Contains(".exe"))
                        {
                            continue;
                        }
                    }
                    var cols = line.Split('#');

                    DataRow row = tbl.NewRow();
                    row.ItemArray = (object[])cols;
                    tbl.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }

            return tbl;
        }

        public static DataTable GetPartnetPriceData()
        {
            string FUNC_NAME = CLASSNAME + System.Reflection.MethodBase.GetCurrentMethod().Name + "(): ";
            Logger.LogInfo("Started:" + FUNC_NAME);

            DataTable tbl = new DataTable();
            try
            {

                //Server#Name#Datetime#Total#Consumed
                tbl.Columns.Add("DEAL_BD_NR", typeof(int));
                tbl.Columns.Add("EUC_ORG_ID", typeof(String));
                tbl.Columns.Add("CURR_CD", typeof(string));
                tbl.Columns.Add("SKU", typeof(string));
                tbl.Columns.Add("LIST_PRICE", typeof(double));
                tbl.Columns.Add("CUST_NET_PRICE", typeof(double));
                tbl.Columns.Add("LAST_MODIFIED_DTS", typeof(DateTime));

                string[] lines = Utils.GetFileRecords(AppDomain.CurrentDomain.BaseDirectory + "PARTNER_PRICING\\PARTNER_PRICING.log");

                bool bSkipFirstLine = true;
                foreach (string line in lines)
                {
                    if (bSkipFirstLine)
                    {
                        bSkipFirstLine = false;
                        continue;
                    }
                    var cols = line.Split('#');

                    DataRow row = tbl.NewRow();
                    row.ItemArray = (object[])cols;
                    tbl.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(FUNC_NAME, ex);
            }

            return tbl;
        }
    }
}