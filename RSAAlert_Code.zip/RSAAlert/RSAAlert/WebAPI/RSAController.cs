﻿using RSAAlert.Common;
using RSAAlert.XMLClasses;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Http;
using System.Xml;
using System.Xml.Serialization;

namespace RSAAlert.WebAPI
{
    public class DiskUsage
    {
        public string name { get; set; }

        public double used { get; set; }

        public double free { get; set; }
    }

    public class MemoryUsage
    {
        public string name { get; set; }

        public List<KeyValuePair<object, double>> Memory_UsageInfo = new List<KeyValuePair<object, double>>();
    }

    public class PARTNER_PRICING
    {
        public int DEAL_BD_NR  { get; set; }
        public string EUC_ORG_ID { get; set; }

        public string CURR_CD { get; set; }
        public string SKU { get; set; }
        public double LIST_PRICE { get; set; }

        public double CUST_NET_PRICE { get; set; }

        public DateTime LAST_MODIFIED_DTS { get; set; }

    }

    public class RSAController : ApiController
    {
        [HttpGet]
        [ActionName("GetString")]
        public string GetString(Int32? id)
        {
            return "This is string returned from RSA";
        }

        [HttpGet]
        [ActionName("GetMemoryUsage")]
        public object GetMemoryUsage(string server, string name)
        {
            if (name == "CPU")
            {
                List<MemoryUsage> memory_list = new List<MemoryUsage>();

                //2018-01-10 08:09:49,795 [24] INFO  RSAAlert Percentage CPU used(g1w9274.austin.hpicorp.net):    23.75
                string[] fileRecords = Utils.GetFileRecords(AppDomain.CurrentDomain.BaseDirectory + "LogFiles\\ServerStat.log");

                DataTable dt = Data.GetData(server, name);

                DataView view = new DataView(dt);
                DataTable distinctValues = view.ToTable(true, "name");

                foreach (DataRow dr in distinctValues.Rows)
                {
                    string processname = dr["name"].ToString();
                    DataRow[] result = dt.Select("name = '" + processname + "'");

                    MemoryUsage objMemoryUsage = new MemoryUsage();
                    objMemoryUsage.name = processname;

                    foreach (DataRow row in result)
                    {
                        var epoch = (Convert.ToDateTime(row["Datetime"]) - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
                        epoch = epoch * 1000;

                        double consumed = Convert.ToDouble(row["Consumed"]);

                        objMemoryUsage.Memory_UsageInfo.Add(new KeyValuePair<object, double>(epoch, consumed));
                    }

                    memory_list.Add(objMemoryUsage);
                }

                return memory_list.ToList();
            }
            else if (name == "Disk")
            {
                SystemCheck objsystemcheck = new SystemCheck();

                string[] fileEntries = System.IO.Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + "InputFiles", "ServerStatConfigs*.*");
                foreach (string DBConfigFilePath in fileEntries)
                {
                    var serializerSSL = new XmlSerializer(typeof(ServerStatConfigs));
                    using (var reader = XmlReader.Create(DBConfigFilePath))
                    {
                        ServerStatConfigs objServerStatConfigs = (ServerStatConfigs)serializerSSL.Deserialize(reader);
                        foreach (ServerStatConfig objServerStatConfig in objServerStatConfigs.ServerStatConfig)
                        {
                            if (objServerStatConfig.PhysicalAddress.Equals(server))
                            {
                                objsystemcheck.computerName = objServerStatConfig.PhysicalAddress;
                                if (!string.IsNullOrEmpty(objServerStatConfig.User))
                                {
                                    objsystemcheck.userid = objServerStatConfig.User;
                                    objsystemcheck.password = RSAAlert.AssetWise.StringCipher.Decrypt(objServerStatConfig.Password.Trim(), "keyforrsa");
                                }
                            }
                        }
                    }
                }

                if (!("localhost").Equals(objsystemcheck.computerName) && string.IsNullOrEmpty(objsystemcheck.userid))
                {
                    return null;
                }
                List<DiskUsage> items = new List<DiskUsage>();

                if (objsystemcheck.GetDiskstats())
                {
                    List<KeyValuePair<String, String>> alertInfo = new List<KeyValuePair<String, String>>();

                    foreach (DiskSpace objDiskSpaceStat in objsystemcheck.lstDiskSpace)
                    {
                        DiskUsage objDiskUsage = new DiskUsage();
                        objDiskUsage.name = objDiskSpaceStat.caption;
                        objDiskUsage.used = Math.Round(objDiskSpaceStat.size_GB - objDiskSpaceStat.freespace_GB, 2);
                        objDiskUsage.free = Math.Round(objDiskSpaceStat.freespace_GB, 2);

                        items.Add(objDiskUsage);
                    }
                }

                return items.ToList();
            }

            return null;
            //string strToCheckinLog = "Percentage CPU used(g1w9274.austin.hpicorp.net)";

            //if (fileRecords != null && fileRecords.Length > 0)
            //{
            //    foreach (string str in fileRecords)
            //    {
            //        if (str.Contains(strToCheckinLog))
            //        {
            //            string[] strArr = str.Split(',');
            //            DateTime dt = Convert.ToDateTime(strArr[0]);
            //            string[] strArr1 = strArr[1].Split(':');
            //            double PercentUsed = Convert.ToDouble(strArr1[1].Trim());

            //            var epoch = (dt.ToUniversalTime() - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
            //            epoch = epoch * 1000;

            //            CPU_UsageInfo.Add(new KeyValuePair<object, double>(epoch, PercentUsed));

            //        }
            //    }
            //}
        }

        [HttpGet]
        [ActionName("GetPARTNER_PRICING")]
        public object GetPARTNER_PRICING()
        {
           // if (name == "CPU")
            {
                List<PARTNER_PRICING> PARTNER_PRICING_list = new List<PARTNER_PRICING>();

                DataTable dt = Data.GetPartnetPriceData();
 
                foreach (DataRow dr in dt.Rows)
                {

                    PARTNER_PRICING objPARTNER_PRICING = new PARTNER_PRICING();

                    objPARTNER_PRICING.DEAL_BD_NR = Convert.ToInt32(dr["DEAL_BD_NR"]);
                    objPARTNER_PRICING.EUC_ORG_ID = Convert.ToString(dr["EUC_ORG_ID"]);

                    objPARTNER_PRICING.CURR_CD = Convert.ToString(dr["CURR_CD"]);
                    objPARTNER_PRICING.SKU = Convert.ToString(dr["SKU"]);
                    objPARTNER_PRICING.LIST_PRICE = Convert.ToDouble(dr["LIST_PRICE"]);

                    objPARTNER_PRICING.CUST_NET_PRICE = Convert.ToDouble(dr["CUST_NET_PRICE"]);

                    objPARTNER_PRICING.LAST_MODIFIED_DTS = Convert.ToDateTime(dr["LAST_MODIFIED_DTS"]);
     
                    PARTNER_PRICING_list.Add(objPARTNER_PRICING);
                }

                return PARTNER_PRICING_list.ToList();
            }

           
        }
    }
}